package com.example.digimartpenjual;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.flexbox.FlexboxLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import android.util.Base64;

public class dashboard_buka_penjual extends AppCompatActivity {

    private Button btnBukaToko, btnUpload, btnEdit, btnSimpan;
    private TextView txtStatus, txtFileChosen, namaToko;
    private EditText deskripsiToko;
    private ImageView imgFotoToko, btnChat;

    private EditText edtNamaToko, edtPemilik, edtKontak;

    private FlexboxLayout flexKategori;

    private boolean isOpen = true;
    private boolean isEditMode = false;

    private static final int PICK_IMAGE = 101;
    private Uri selectedImageUri;
    private String selectedImageBase64 = null;
    private boolean isPreviewingLocalImage = false;

    private DatabaseReference dbToko;

    // DEFAULT hanya fallback kalau tidak dapat dari Intent/session
    private String idPenjual = "Toko001";

    private final Set<String> kategoriDipilih = new HashSet<>();
    private static final int MAX_KATEGORI = 2;

    // ===== OPTIONAL: sesi (kalau kamu sudah simpan di login) =====
    private static final String PREFS = "digimart_penjual_session";
    private static final String KEY_ACTIVE_ID = "active_penjual_id";

    private static class ChipStyle {
        final Drawable bg;
        final int textColor;
        ChipStyle(Drawable bg, int textColor) {
            this.bg = bg;
            this.textColor = textColor;
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_buka_penjual);

        // Bind view
        btnBukaToko = findViewById(R.id.btnBukaToko);
        btnUpload   = findViewById(R.id.btnUpload);
        btnEdit     = findViewById(R.id.btnEdit);
        btnSimpan   = findViewById(R.id.btnSimpan);

        txtStatus      = findViewById(R.id.txtStatusToko);
        txtFileChosen  = findViewById(R.id.txtFileChosen);
        deskripsiToko  = findViewById(R.id.deskripsiToko);
        namaToko       = findViewById(R.id.namaToko);

        imgFotoToko = findViewById(R.id.imgFotoToko);
        btnChat     = findViewById(R.id.btnChat);

        edtNamaToko = findViewById(R.id.edtNamaToko);
        edtPemilik  = findViewById(R.id.edtPemilik);
        edtKontak   = findViewById(R.id.edtKontak);

        flexKategori = findViewById(R.id.flexKategori);

        // ==============================
        // FIX UTAMA: ambil idPenjual dari login (Intent / session)
        // ==============================
        idPenjual = resolvePenjualId();
        dbToko = FirebaseDatabase.getInstance().getReference("Penjual").child(idPenjual);

        // Reset UI dulu supaya tidak “nyangkut” dari akun sebelumnya
        resetUiKosong();

        setEditMode(false);
        cacheChipDefaultStyles(flexKategori);

        // ===== CHAT BUTTON CLICK =====
        btnChat.setOnClickListener(v -> {
            Intent intent = new Intent(dashboard_buka_penjual.this, isichat_admin_penjual2.class);
            intent.putExtra("penjualId", idPenjual); // kirim penjualId YANG BENAR
            startActivity(intent);
        });

        // Ambil status realtime
        dbToko.child("status").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String status = snapshot.getValue(String.class);
                    isOpen = "BUKA".equals(status);
                    updateUI();
                } else {
                    // Kalau belum ada data status untuk penjual baru, set default yang aman
                    isOpen = false;
                    updateUI();
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Ambil deskripsi realtime
        dbToko.child("deskripsi").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String desc = snapshot.getValue(String.class);
                    if (desc != null) deskripsiToko.setText(desc);
                } else {
                    // penjual baru: biarkan kosong
                    deskripsiToko.setText("");
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Nama toko
        dbToko.child("namaToko").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String val = snapshot.getValue(String.class);
                    if (val != null) {
                        edtNamaToko.setText(val);
                        namaToko.setText(val);
                    }
                } else {
                    // penjual baru: kosong
                    edtNamaToko.setText("");
                    namaToko.setText("");
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Pemilik & Kontak
        dbToko.child("pemilik").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String val = snapshot.getValue(String.class);
                    if (val != null) edtPemilik.setText(val);
                } else {
                    edtPemilik.setText("");
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        dbToko.child("kontak").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String val = snapshot.getValue(String.class);
                    if (val != null) edtKontak.setText(val);
                } else {
                    edtKontak.setText("");
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Kategori multi
        dbToko.child("kategori").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                kategoriDipilih.clear();
                if (snapshot.exists()) {
                    Object val = snapshot.getValue();
                    if (val instanceof List) {
                        List<?> list = (List<?>) val;
                        for (Object o : list) if (o != null) kategoriDipilih.add(String.valueOf(o).trim());
                    } else if (val instanceof String) {
                        String single = (String) val;
                        if (!single.trim().isEmpty()) kategoriDipilih.add(single.trim());
                    } else {
                        for (DataSnapshot c : snapshot.getChildren()) {
                            String k = c.getValue(String.class);
                            if (k != null && !k.trim().isEmpty()) kategoriDipilih.add(k.trim());
                        }
                    }
                }
                highlightKategoriMulti(flexKategori, kategoriDipilih);
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Foto toko
        dbToko.child("fotoTokoBase64").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isPreviewingLocalImage && isEditMode) return;

                if (snapshot.exists()) {
                    String base64 = snapshot.getValue(String.class);
                    if (base64 != null && !base64.isEmpty()) {
                        try {
                            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            imgFotoToko.setImageBitmap(bmp);
                        } catch (Exception ignored) { }
                    }
                } else {
                    // penjual baru: foto kosong (biarkan default image di layout)
                    // Jika mau reset keras, uncomment:
                    // imgFotoToko.setImageDrawable(null);
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });

        // Klik kategori
        for (int i = 0; i < flexKategori.getChildCount(); i++) {
            final View chip = flexKategori.getChildAt(i);
            chip.setOnClickListener(v -> {
                if (!isEditMode) { toast("Klik Edit dulu untuk ubah kategori."); return; }
                if (!(v instanceof TextView)) return;
                String k = ((TextView) v).getText().toString().trim();
                if (k.isEmpty()) return;
                if (kategoriDipilih.contains(k)) kategoriDipilih.remove(k);
                else {
                    if (kategoriDipilih.size() >= MAX_KATEGORI) { toast("Maksimal " + MAX_KATEGORI + " kategori."); return; }
                    kategoriDipilih.add(k);
                }
                dbToko.child("kategori").setValue(new ArrayList<>(kategoriDipilih));
                highlightKategoriMulti(flexKategori, kategoriDipilih);
            });
        }

        // Tombol buka/tutup toko
        btnBukaToko.setOnClickListener(v -> {
            isOpen = !isOpen;
            String newStatus = isOpen ? "BUKA" : "TUTUP";
            dbToko.child("status").setValue(newStatus);
        });

        // Tombol edit
        btnEdit.setOnClickListener(v -> setEditMode(true));

        // Tombol upload foto
        btnUpload.setOnClickListener(v -> {
            if (!isEditMode) { toast("Klik Edit dulu untuk pilih foto."); return; }
            pilihFoto();
        });

        // Tombol simpan
        btnSimpan.setOnClickListener(v -> {
            if (!isEditMode) return;
            String nama = edtNamaToko.getText().toString().trim();
            String pemilik = edtPemilik.getText().toString().trim();
            String kontak = edtKontak.getText().toString().trim();
            dbToko.child("namaToko").setValue(nama);
            dbToko.child("pemilik").setValue(pemilik);
            dbToko.child("kontak").setValue(kontak);
            if (!nama.isEmpty()) namaToko.setText(nama);

            String desc = deskripsiToko.getText().toString().trim();
            dbToko.child("deskripsi").setValue(desc);

            if (selectedImageBase64 != null && !selectedImageBase64.isEmpty()) simpanFotoBase64KeRTDB();
            else {
                setEditMode(false);
                isPreviewingLocalImage = false;
                toast("Berhasil disimpan.");
            }
        });
    }

    // ==============================
    // Ambil id penjual dari Intent/saved session
    // ==============================
    private String resolvePenjualId() {
        String fromIntent = null;
        if (getIntent() != null) {
            fromIntent = getIntent().getStringExtra("penjualId");
            if (fromIntent == null || fromIntent.trim().isEmpty()) {
                fromIntent = getIntent().getStringExtra("idPenjual");
            }
        }
        if (fromIntent != null && !fromIntent.trim().isEmpty()) {
            return fromIntent.trim();
        }

        // fallback session (opsional, tidak mengganggu kalau belum dipakai)
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = sp.getString(KEY_ACTIVE_ID, null);
        if (saved != null && !saved.trim().isEmpty()) {
            return saved.trim();
        }

        // fallback terakhir
        return idPenjual;
    }

    // ==============================
    // Reset UI supaya penjual baru tampil kosong
    // ==============================
    private void resetUiKosong() {
        // field teks
        edtNamaToko.setText("");
        edtPemilik.setText("");
        edtKontak.setText("");
        deskripsiToko.setText("");
        namaToko.setText("");
        txtFileChosen.setText("");

        // kategori
        kategoriDipilih.clear();
        highlightKategoriMulti(flexKategori, kategoriDipilih);

        // status default aman (tutup)
        isOpen = false;
        updateUI();

        // foto: biarkan default dari layout (kalau layout sudah ada placeholder)
        selectedImageUri = null;
        selectedImageBase64 = null;
        isPreviewingLocalImage = false;
    }

    private void setEditMode(boolean enabled) {
        isEditMode = enabled;
        deskripsiToko.setEnabled(enabled);
        edtNamaToko.setEnabled(enabled);
        edtPemilik.setEnabled(enabled);
        edtKontak.setEnabled(enabled);
        btnUpload.setEnabled(enabled);
        btnSimpan.setEnabled(enabled);
        btnSimpan.setAlpha(enabled ? 1f : 0.5f);
        btnEdit.setEnabled(!enabled);
        btnEdit.setAlpha(!enabled ? 1f : 0.5f);
        if (!enabled) isPreviewingLocalImage = false;
    }

    private void cacheChipDefaultStyles(FlexboxLayout flex) {
        if (flex == null) return;
        for (int i = 0; i < flex.getChildCount(); i++) {
            View child = flex.getChildAt(i);
            if (!(child instanceof TextView)) continue;
            TextView chip = (TextView) child;
            Drawable bg = chip.getBackground();
            Drawable copyBg = bg != null && bg.getConstantState() != null ? bg.getConstantState().newDrawable().mutate() : null;
            int tc = chip.getCurrentTextColor();
            chip.setTag(new ChipStyle(copyBg, tc));
        }
    }

    private void restoreChipDefaultStyle(TextView chip) {
        Object tag = chip.getTag();
        if (tag instanceof ChipStyle) {
            ChipStyle st = (ChipStyle) tag;
            if (st.bg != null) chip.setBackground(st.bg);
            chip.setTextColor(st.textColor);
        } else {
            chip.setBackgroundColor(Color.parseColor("#EEEEEE"));
            chip.setTextColor(Color.BLACK);
        }
    }

    private void highlightKategoriMulti(FlexboxLayout flex, Set<String> selectedSet) {
        if (flex == null) return;
        for (int i = 0; i < flex.getChildCount(); i++) {
            View child = flex.getChildAt(i);
            if (!(child instanceof TextView)) continue;
            TextView chip = (TextView) child;
            String teks = chip.getText().toString().trim();
            if (selectedSet != null && selectedSet.contains(teks)) {
                chip.setBackgroundColor(Color.parseColor("#2E7D32"));
                chip.setTextColor(Color.WHITE);
            } else restoreChipDefaultStyle(chip);
        }
    }

    private void pilihFoto() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Pilih Foto Toko"), PICK_IMAGE);
    }

    private void simpanFotoBase64KeRTDB() {
        dbToko.child("fotoTokoBase64").setValue(selectedImageBase64)
                .addOnSuccessListener(unused -> {
                    selectedImageUri = null;
                    selectedImageBase64 = null;
                    txtFileChosen.setText("Uploaded");
                    isPreviewingLocalImage = false;
                    setEditMode(false);
                    toast("Foto berhasil disimpan.");
                })
                .addOnFailureListener(e -> toast("Simpan foto gagal: " + e.getMessage()));
    }

    private void updateUI() {
        if (isOpen) {
            txtStatus.setText("BUKA");
            txtStatus.setTextColor(Color.parseColor("#2E7D32"));
            btnBukaToko.setText("Tutup Toko");
        } else {
            txtStatus.setText("TUTUP");
            txtStatus.setTextColor(Color.parseColor("#FE5D26"));
            btnBukaToko.setText("Buka Toko");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                isPreviewingLocalImage = true;
                imgFotoToko.clearColorFilter();
                imgFotoToko.setImageURI(selectedImageUri);
                txtFileChosen.setText("1 file chosen");
                selectedImageBase64 = uriToBase64(selectedImageUri);
                if (selectedImageBase64 == null) toast("Gagal membaca gambar. Coba pilih ulang.");
            }
        }
    }

    private String uriToBase64(Uri uri) {
        try {
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
                bitmap = ImageDecoder.decodeBitmap(source);
            } else bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);

            bitmap = resizeBitmap(bitmap, 512);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
            byte[] bytes = baos.toByteArray();
            return Base64.encodeToString(bytes, Base64.DEFAULT);
        } catch (IOException e) {
            return null;
        }
    }

    private Bitmap resizeBitmap(Bitmap src, int maxSize) {
        int w = src.getWidth(), h = src.getHeight();
        if (w <= maxSize && h <= maxSize) return src;
        float ratio = (float) w / h;
        int newW = ratio > 1 ? maxSize : (int)(maxSize * ratio);
        int newH = ratio > 1 ? (int)(maxSize / ratio) : maxSize;
        return Bitmap.createScaledBitmap(src, newW, newH, true);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
