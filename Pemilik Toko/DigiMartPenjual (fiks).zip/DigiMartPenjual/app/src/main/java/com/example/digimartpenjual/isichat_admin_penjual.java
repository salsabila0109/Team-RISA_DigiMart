package com.example.digimartpenjual;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class isichat_admin_penjual extends AppCompatActivity {

    private ImageView btnBack;
    private Button btnTerima;

    private ScrollView scrollView;
    private LinearLayout chatContainer;

    private EditText edtMessage;
    private ImageButton btnSend;

    private DatabaseReference roomRef;
    private ValueEventListener chatListener;

    private String penjualId = "Toko001";
    private String pembeliId = "PEMBELI001";
    private String pembeliName = "Pembeli";

    private final String myRole = "penjual";

    // ===== BOT 1x =====
    private DatabaseReference botFlagRef;
    private Query botQuery;
    private ChildEventListener botListener;
    private String initialLastKey = null;
    private static final String BOT_GREETING = "Halo, ada yang bisa di bantu?";

    // ====== HEADER "AKTIF ..." DINAMIS (NEW) ======
    private TextView tvAktifStatus;
    private long lastOtherActivityTs = 0L;
    private final Handler aktifHandler = new Handler(Looper.getMainLooper());
    private Runnable aktifRunnable;

    // Listener untuk ambil pesan terakhir lawan chat (agar "Aktif ..." berubah)
    private Query lastOtherMsgQuery;
    private ValueEventListener lastOtherMsgListener;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_isichat_admin_penjual);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        if (getIntent() != null) {
            String p = getIntent().getStringExtra("penjualId");
            String b = getIntent().getStringExtra("pembeliId");
            String n = getIntent().getStringExtra("pembeliName");
            if (p != null && !p.trim().isEmpty()) penjualId = p.trim();
            if (b != null && !b.trim().isEmpty()) pembeliId = b.trim();
            if (n != null && !n.trim().isEmpty()) pembeliName = n.trim();
        }

        // Ganti nama header chat
        replaceHeaderName("iren", pembeliName);

        // Ambil TextView status "Aktif ..." dari header (tanpa ubah XML)
        tvAktifStatus = findHeaderAktifTextView(findViewById(android.R.id.content));
        if (tvAktifStatus != null) {
            // Set awal supaya tidak stuck 32 menit
            tvAktifStatus.setText("Aktif baru saja");
        }

        View root = findViewById(android.R.id.content);
        scrollView = findFirstScrollView(root);

        if (scrollView == null) {
            Toast.makeText(this, "ScrollView chat tidak ditemukan di layout.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (scrollView.getChildCount() > 0 && scrollView.getChildAt(0) instanceof LinearLayout) {
            chatContainer = (LinearLayout) scrollView.getChildAt(0);
        } else {
            chatContainer = new LinearLayout(this);
            chatContainer.setOrientation(LinearLayout.VERTICAL);
            scrollView.addView(chatContainer);
        }

        chatContainer.removeAllViews();

        ViewGroup.LayoutParams pScroll = scrollView.getLayoutParams();
        if (pScroll instanceof LinearLayout.LayoutParams) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) pScroll;
            lp.height = 0;
            lp.weight = 1f;
            scrollView.setLayoutParams(lp);
        }

        attachInputBar();

        if (btnTerima != null) {
            btnTerima.setOnClickListener(v -> {
                kirimChat(myRole, "Baik, pesanan Anda sudah kami terima dan akan segera diproses.");
            });
        }

        String roomId = buildRoomId(penjualId, pembeliId);
        roomRef = FirebaseDatabase.getInstance().getReference("chat_pp").child(roomId);

        // Realtime chat
        listenChatRealtime();

        // Aktif dinamis berdasarkan aktivitas lawan chat (pesan terakhir lawan)
        attachActiveStatusFromLastOtherMessage();

        // BOT hanya untuk pembeli (bukan admin)
        if (!isAdminChat(pembeliId)) {
            attachBotGreetingOnce();
        }

        // Mulai ticker update "Aktif ..." (tiap 30 detik)
        startAktifTicker();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (roomRef != null && chatListener != null) {
            roomRef.removeEventListener(chatListener);
        }

        if (botQuery != null && botListener != null) {
            botQuery.removeEventListener(botListener);
        }

        if (lastOtherMsgQuery != null && lastOtherMsgListener != null) {
            lastOtherMsgQuery.removeEventListener(lastOtherMsgListener);
        }

        stopAktifTicker();
    }

    private boolean isAdminChat(@NonNull String otherId) {
        return otherId.toLowerCase().contains("admin");
    }

    private void attachInputBar() {
        ViewGroup content = findViewById(android.R.id.content);
        ViewGroup root = (ViewGroup) content.getChildAt(0);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(16, 12, 16, 12);
        bar.setBackgroundColor(Color.parseColor("#FFF8F0"));

        edtMessage = new EditText(this);
        edtMessage.setHint("Tulis pesan...");
        edtMessage.setMinLines(1);
        edtMessage.setMaxLines(4);
        edtMessage.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        edtMessage.setBackground(null);

        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        edtMessage.setLayoutParams(etLp);

        btnSend = new ImageButton(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setScaleType(ImageButton.ScaleType.CENTER);
        btnSend.setPadding(22, 22, 22, 22);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(999f);
        bg.setColor(Color.parseColor("#FE5D26"));
        btnSend.setBackground(bg);

        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        sendLp.setMargins(16, 0, 0, 0);
        btnSend.setLayoutParams(sendLp);

        btnSend.setOnClickListener(v -> {
            String msg = edtMessage.getText().toString().trim();
            if (!msg.isEmpty()) {
                kirimChat(myRole, msg);
                edtMessage.setText("");
            }
        });

        bar.addView(edtMessage);
        bar.addView(btnSend);
        root.addView(bar);
    }

    private void listenChatRealtime() {
        // ORDER BY timestamp agar urutan sesuai waktu
        Query q = roomRef.orderByChild("timestamp");

        chatListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                chatContainer.removeAllViews();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    if (!ds.hasChild("sender") || !ds.hasChild("message") || !ds.hasChild("timestamp")) continue;

                    String sender = ds.child("sender").getValue(String.class);
                    String message = ds.child("message").getValue(String.class);

                    if (sender == null) sender = "";
                    if (message == null) message = "";

                    if (myRole.equals(sender)) addBubbleRight(message);
                    else addBubbleLeft(message);
                }

                autoScrollBottom();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        q.addValueEventListener(chatListener);
    }

    // =========================
    // AKTIF DINAMIS: ambil pesan terakhir dari lawan chat, update lastOtherActivityTs
    // =========================
    private void attachActiveStatusFromLastOtherMessage() {
        lastOtherMsgQuery = roomRef.orderByChild("timestamp").limitToLast(1);

        lastOtherMsgListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                String sender = null;
                Long ts = null;

                for (DataSnapshot ds : snapshot.getChildren()) {
                    sender = ds.child("sender").getValue(String.class);
                    ts = safeLong(ds.child("timestamp").getValue());
                }

                if (sender == null || ts == null) return;

                // kalau pesan terakhir dari LAWAN chat -> pakai untuk "Aktif ..."
                if (!myRole.equalsIgnoreCase(sender)) {
                    lastOtherActivityTs = ts;
                    updateAktifTextNow();
                } else {
                    // bila pesan terakhir dari penjual, tetap tampilkan berdasarkan lastOtherActivityTs yang lama
                    updateAktifTextNow();
                }
            }

            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        lastOtherMsgQuery.addValueEventListener(lastOtherMsgListener);
    }

    private void startAktifTicker() {
        if (tvAktifStatus == null) return;

        if (aktifRunnable == null) {
            aktifRunnable = new Runnable() {
                @Override public void run() {
                    updateAktifTextNow();
                    aktifHandler.postDelayed(this, 30_000); // update tiap 30 detik
                }
            };
        }
        aktifHandler.removeCallbacks(aktifRunnable);
        aktifHandler.post(aktifRunnable);
    }

    private void stopAktifTicker() {
        if (aktifRunnable != null) aktifHandler.removeCallbacks(aktifRunnable);
    }

    private void updateAktifTextNow() {
        if (tvAktifStatus == null) return;

        if (lastOtherActivityTs <= 0L) {
            tvAktifStatus.setText("Aktif");
            return;
        }

        long now = System.currentTimeMillis();
        long diffMs = Math.max(0L, now - lastOtherActivityTs);

        long diffMin = diffMs / 60_000L;
        long diffHour = diffMs / 3_600_000L;
        long diffDay = diffMs / 86_400_000L;

        if (diffMin <= 0) {
            tvAktifStatus.setText("Aktif baru saja");
        } else if (diffMin < 60) {
            tvAktifStatus.setText("Aktif " + diffMin + " menit yang lalu");
        } else if (diffHour < 24) {
            tvAktifStatus.setText("Aktif " + diffHour + " jam yang lalu");
        } else {
            tvAktifStatus.setText("Aktif " + diffDay + " hari yang lalu");
        }
    }

    // Cari TextView header yang diawali "Aktif" tanpa ubah XML
    private TextView findHeaderAktifTextView(View v) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            CharSequence cs = tv.getText();
            if (cs != null) {
                String t = cs.toString().trim();
                if (t.startsWith("Aktif")) return tv;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                TextView found = findHeaderAktifTextView(vg.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    // =========================
    // BOT 1x: balas otomatis sekali untuk pesan pembeli, urutan pasti benar
    // =========================
    private void attachBotGreetingOnce() {
        botFlagRef = roomRef.child("_meta").child("botGreetingSent");

        roomRef.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                initialLastKey = null;
                for (DataSnapshot ds : snap.getChildren()) {
                    initialLastKey = ds.getKey();
                }

                botQuery = roomRef.orderByKey().startAt(initialLastKey == null ? "" : initialLastKey);

                botListener = new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot ds, String previousChildName) {
                        String key = ds.getKey();
                        if (key == null) return;

                        if ("_meta".equals(key)) return;
                        if (initialLastKey != null && initialLastKey.equals(key)) return;

                        if (!ds.hasChild("sender") || !ds.hasChild("message") || !ds.hasChild("timestamp")) return;

                        String sender = ds.child("sender").getValue(String.class);
                        Boolean isBot = ds.child("bot").getValue(Boolean.class);

                        if (sender == null) sender = "";
                        if (isBot != null && isBot) return;

                        if (!isBuyerSender(sender)) return;

                        final Long buyerTs = safeLong(ds.child("timestamp").getValue());

                        botFlagRef.runTransaction(new Transaction.Handler() {
                            @NonNull
                            @Override
                            public Transaction.Result doTransaction(@NonNull MutableData currentData) {
                                Boolean sent = currentData.getValue(Boolean.class);
                                if (sent != null && sent) return Transaction.abort();
                                currentData.setValue(true);
                                return Transaction.success(currentData);
                            }

                            @Override
                            public void onComplete(DatabaseError error, boolean committed, DataSnapshot currentData) {
                                if (error != null || !committed) return;

                                long tsBot = (buyerTs != null) ? (buyerTs + 1L) : System.currentTimeMillis();
                                kirimChat(myRole, BOT_GREETING, true, tsBot);
                            }
                        });
                    }

                    @Override public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) { }
                    @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
                    @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) { }
                    @Override public void onCancelled(@NonNull DatabaseError error) { }
                };

                botQuery.addChildEventListener(botListener);
            }

            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private boolean isBuyerSender(@NonNull String sender) {
        return sender.equalsIgnoreCase("pembeli")
                || sender.equalsIgnoreCase("user")
                || sender.equalsIgnoreCase(pembeliId);
    }

    private Long safeLong(Object v) {
        if (v == null) return null;
        if (v instanceof Long) return (Long) v;
        if (v instanceof Integer) return ((Integer) v).longValue();
        if (v instanceof Double) return ((Double) v).longValue();
        if (v instanceof Float) return ((Float) v).longValue();
        if (v instanceof String) {
            try { return Long.parseLong((String) v); } catch (Exception ignored) { }
        }
        return null;
    }

    private void kirimChat(@NonNull String sender, @NonNull String message) {
        kirimChat(sender, message, false, System.currentTimeMillis());
    }

    private void kirimChat(@NonNull String sender,
                           @NonNull String message,
                           boolean bot,
                           long timestamp) {

        String id = roomRef.push().getKey();
        if (id == null) return;

        Map<String, Object> data = new HashMap<>();
        data.put("sender", sender);
        data.put("message", message);

        // FIX URUTAN CHAT:
        // - untuk pesan normal: pakai ServerValue.TIMESTAMP supaya waktu konsisten (balasan tidak "naik ke atas")
        // - untuk bot: tetap pakai timestamp numerik (buyerTs + 1) agar bot selalu setelah pesan pembeli
        if (bot) {
            data.put("timestamp", timestamp);
            data.put("bot", true);
        } else {
            data.put("timestamp", ServerValue.TIMESTAMP);
        }

        roomRef.child(id).setValue(data);
    }

    private void autoScrollBottom() {
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void addBubbleRight(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        tv.setPadding(22, 16, 22, 16);

        GradientDrawable b = new GradientDrawable();
        b.setCornerRadius(24f);
        b.setColor(Color.parseColor("#FFCCBC"));
        tv.setBackground(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.gravity = Gravity.END;
        lp.setMargins(70, 12, 0, 12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    private void addBubbleLeft(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        tv.setPadding(22, 16, 22, 16);

        GradientDrawable b = new GradientDrawable();
        b.setCornerRadius(24f);
        b.setColor(Color.WHITE);
        tv.setBackground(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.gravity = Gravity.START;
        lp.setMargins(0, 12, 70, 12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    private String buildRoomId(@NonNull String penjualId, @NonNull String pembeliId) {
        return (penjualId.compareTo(pembeliId) < 0)
                ? (penjualId + "_" + pembeliId)
                : (pembeliId + "_" + penjualId);
    }

    private ScrollView findFirstScrollView(View root) {
        if (root instanceof ScrollView) return (ScrollView) root;
        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for (int i = 0; i < vg.getChildCount(); i++) {
                ScrollView r = findFirstScrollView(vg.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    private void replaceHeaderName(@NonNull String oldText, @NonNull String newText) {
        View root = findViewById(android.R.id.content);
        replaceTextRecursive(root, oldText, newText);
    }

    private void replaceTextRecursive(View v, String oldText, String newText) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            if (tv.getText() != null && oldText.equals(tv.getText().toString())) {
                tv.setText(newText);
                return;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                replaceTextRecursive(vg.getChildAt(i), oldText, newText);
            }
        }
    }
}
