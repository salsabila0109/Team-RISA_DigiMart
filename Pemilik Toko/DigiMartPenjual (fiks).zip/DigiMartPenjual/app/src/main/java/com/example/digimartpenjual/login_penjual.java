package com.example.digimartpenjual;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public class login_penjual extends AppCompatActivity {

    EditText etIdSlot, etPassword;
    Button btnMasuk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_penjual);

        etIdSlot = findViewById(R.id.etIdSlot);
        etPassword = findViewById(R.id.etPassword);
        btnMasuk = findViewById(R.id.btnMasukPembeli);

        // ================================
        // TEKS JADI BOLD SAAT DIKETIK
        // ================================
        etIdSlot.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etIdSlot.setTypeface(null, Typeface.BOLD);
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        etPassword.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etPassword.setTypeface(null, Typeface.BOLD);
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        // ================================
        // LOGIN PENJUAL
        // ================================
        btnMasuk.setOnClickListener(v -> {

            String idSlot = etIdSlot.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (idSlot.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "ID Slot dan Password wajib diisi!",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // =====================================
            // LOGIN SESUAI DATA ADMIN (TANPA AUTO-REGISTER)
            // - Jika idSlot belum ada -> "ID Slot tidak terdaftar"
            // - Jika idSlot ada tapi password salah -> "Password salah"
            // - Jika benar -> login
            // =====================================
            DatabaseReference sellerRef = FirebaseDatabase.getInstance()
                    .getReference("Users")
                    .child("penjual")
                    .child(idSlot);

            sellerRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    // 1) ID Slot tidak terdaftar
                    if (!snapshot.exists()) {
                        Toast.makeText(login_penjual.this,
                                "ID Slot tidak terdaftar",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // 2) ID Slot terdaftar -> cek password
                    String passwordDB = snapshot.child("password").getValue(String.class);

                    if (passwordDB == null) {
                        // Kalau data di firebase rusak/tidak lengkap
                        Toast.makeText(login_penjual.this,
                                "Akun tidak valid. Hubungi admin.",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // 3) Password salah
                    if (!passwordDB.equals(password)) {
                        Toast.makeText(login_penjual.this,
                                "Password salah",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // 4) Login berhasil
                    Toast.makeText(login_penjual.this,
                            "Login Berhasil!",
                            Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(login_penjual.this, dashboard_buka_penjual.class);
                    intent.putExtra("penjualId", idSlot); // penting agar dashboard baca data sesuai id slot
                    startActivity(intent);
                    finish();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(login_penjual.this,
                            "Firebase Error: " + error.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // ===================================================
    // FUNGSI UNTUK MENYIMPAN PENJUAL KE FIREBASE REALTIME
    // (Tetap ada, tapi tidak dipakai di login agar sesuai skenario admin)
    // ===================================================
    private void simpanPenjualKeFirebase(String idSlot, String password) {
        DatabaseReference db = FirebaseDatabase.getInstance()
                .getReference("Users")
                .child("penjual")
                .child(idSlot);

        db.child("idSlot").setValue(idSlot);
        db.child("password").setValue(password);

        Toast.makeText(this,
                "Akun penjual disimpan ke Firebase!",
                Toast.LENGTH_SHORT).show();
    }
}
