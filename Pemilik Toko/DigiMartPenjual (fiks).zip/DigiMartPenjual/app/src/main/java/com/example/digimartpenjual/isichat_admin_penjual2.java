package com.example.digimartpenjual;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class isichat_admin_penjual2 extends AppCompatActivity {

    private ImageView btnBack;

    // Default mengikuti pola project-mu
    private String penjualId = "Toko001";

    // === SET ADMIN ID ANDA DI SINI ===
    private static final String ADMIN_ID = "ADMIN001";

    private final DatabaseReference chatRootRef =
            FirebaseDatabase.getInstance().getReference("chat_pp");

    // Container list chat (dibuat via Java agar tidak perlu ubah XML)
    private LinearLayout listContainer;

    // Simpan thread
    private final Map<String, ThreadInfo> threadMap = new HashMap<>();
    private boolean hasRealAdminThread = false;

    // Listener
    private ChildEventListener roomListener;

    // sender penjual di tabel chat_pp (tetap sesuai project kamu)
    private static final String SELLER_SENDER = "penjual";

    // =========================
    // NOTIF HP (NEW)
    // =========================
    private static final String NOTIF_CHANNEL_ID = "chat_channel";
    private static final int REQ_POST_NOTIF = 991;
    private static final String SP_NAME = "chat_notif_sp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // WAJIB pakai layout chat luar
        setContentView(R.layout.activity_isichat_admin_penjual2);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        if (getIntent() != null) {
            String p = getIntent().getStringExtra("penjualId");
            if (p != null && !p.trim().isEmpty()) penjualId = p.trim();
        }

        // NOTIF HP: channel + permission
        prepareNotification();

        // Buat list container dinamis (scrollable) tanpa ubah XML
        setupDynamicListContainer();

        // Load awal + pasang listener realtime
        loadInitialThreadsThenListen();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (roomListener != null) {
            chatRootRef.removeEventListener(roomListener);
        }

        // Lepas listener per-room agar tidak leak
        for (ThreadInfo t : threadMap.values()) {
            if (t.lastQuery != null && t.lastListener != null) {
                t.lastQuery.removeEventListener(t.lastListener);
            }
            if (t.seenRef != null && t.seenListener != null) {
                t.seenRef.removeEventListener(t.seenListener);
            }
            // NEW: notif listener
            if (t.notifQuery != null && t.notifListener != null) {
                t.notifQuery.removeEventListener(t.notifListener);
            }
        }
    }

    // =========================
    // NOTIF HP: setup
    // =========================
    private void prepareNotification() {
        // Channel (Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIF_CHANNEL_ID,
                    "Chat Notification",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notifikasi pesan chat baru");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }

        // Permission (Android 13+)
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_POST_NOTIF
                );
            }
        }
    }

    private void showNotification(@NonNull ThreadInfo t, @NonNull String text) {
        // Jika permission belum ada (Android 13+), stop
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        String title = (t.displayName != null && !t.displayName.trim().isEmpty())
                ? t.displayName
                : (t.isAdmin ? "Admin" : "Pembeli");

        // Tap notif -> buka chat dalam langsung
        Intent intent = new Intent(this, isichat_admin_penjual.class);
        intent.putExtra("penjualId", penjualId);
        intent.putExtra("pembeliId", t.otherId);
        intent.putExtra("pembeliName", title);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pi = PendingIntent.getActivity(
                this,
                Math.abs(t.roomId.hashCode()),
                intent,
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)
                        : PendingIntent.FLAG_UPDATE_CURRENT
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher) // aman (pasti ada)
                .setContentTitle("Pesan baru - " + title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManagerCompat.from(this).notify(Math.abs(t.roomId.hashCode()), builder.build());
    }

    // =========================
    // UI: bikin container list sendiri (scroll)
    // =========================
    private void setupDynamicListContainer() {
        ViewGroup content = findViewById(android.R.id.content);
        if (content == null || content.getChildCount() == 0) return;

        // Root dari activity_isichat_admin_penjual2.xml (LinearLayout vertical)
        View rootView = content.getChildAt(0);
        if (!(rootView instanceof ViewGroup)) return;

        ViewGroup root = (ViewGroup) rootView;

        // Pertahankan HEADER (child ke-0), bersihkan sisanya supaya tidak bentrok dengan item statis XML
        while (root.getChildCount() > 1) {
            root.removeViewAt(1);
        }

        // Buat ScrollView + listContainer
        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        sv.setLayoutParams(svLp);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setBackgroundColor(Color.parseColor("#FFF3E0"));
        listContainer.setPadding(dp(8), dp(8), dp(8), dp(8));

        sv.addView(listContainer, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        root.addView(sv);
    }

    // =========================
    // DATA: initial load -> pin admin -> realtime rooms
    // =========================
    private void loadInitialThreadsThenListen() {
        chatRootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                hasRealAdminThread = false;

                for (DataSnapshot roomSnap : snapshot.getChildren()) {
                    String roomId = roomSnap.getKey();
                    if (roomId == null) continue;
                    addThreadFromRoomId(roomId);
                }

                // Kalau belum ada room admin sama sekali, tetap tampilkan admin pinned (placeholder)
                if (!hasRealAdminThread) {
                    String adminRoom = buildRoomId(penjualId, ADMIN_ID);
                    if (!threadMap.containsKey(adminRoom)) {
                        ThreadInfo tAdmin = new ThreadInfo(adminRoom, ADMIN_ID, true);
                        threadMap.put(adminRoom, tAdmin);
                        ensureThreadBound(tAdmin);
                    }
                }

                rebuildListUI();
                attachRoomRealtimeListener();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {
                attachRoomRealtimeListener();
            }
        });
    }

    private void attachRoomRealtimeListener() {
        if (roomListener != null) return;

        roomListener = new ChildEventListener() {
            @Override public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {
                String roomId = snapshot.getKey();
                if (roomId == null) return;

                boolean added = addThreadFromRoomId(roomId);
                if (added) rebuildListUI();
            }

            @Override public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {
                // tidak perlu, karena preview last message di-handle listener per-room
            }

            @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
            @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) { }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        chatRootRef.addChildEventListener(roomListener);
    }

    // return true kalau benar-benar menambah thread baru
    private boolean addThreadFromRoomId(@NonNull String roomId) {
        // roomId format: A_B
        String[] parts = roomId.split("_");
        if (parts.length != 2) return false;

        String a = parts[0];
        String b = parts[1];

        if (!a.equals(penjualId) && !b.equals(penjualId)) return false;

        String otherId = a.equals(penjualId) ? b : a;

        boolean isAdmin = isAdminId(otherId);
        if (isAdmin) hasRealAdminThread = true;

        if (threadMap.containsKey(roomId)) return false;

        ThreadInfo t = new ThreadInfo(roomId, otherId, isAdmin);
        threadMap.put(roomId, t);
        ensureThreadBound(t);
        return true;
    }

    // =========================
    // Bind per thread: view + name + last msg listener + seen listener + notif listener (NEW)
    // =========================
    private void ensureThreadBound(@NonNull ThreadInfo t) {
        if (t.wrapper == null) {
            t.wrapper = createThreadRowView(t);
        }

        // resolve nama (bukan ID)
        resolveUserName(t.otherId, t.isAdmin, name -> {
            t.displayName = name;
            updateRowTexts(t);
            rebuildListUI(); // agar urutan & tampilan konsisten
        });

        // listen last message realtime untuk thread ini
        attachLastMessageListener(t);

        // listen "seen" timestamp untuk penjual -> menentukan titik merah
        attachSeenListener(t);

        // NOTIF HP (NEW)
        attachPhoneNotifListener(t);
    }

    private void attachLastMessageListener(@NonNull ThreadInfo t) {
        if (t.lastQuery != null && t.lastListener != null) return;

        t.lastQuery = chatRootRef.child(t.roomId)
                .orderByChild("timestamp")
                .limitToLast(1);

        t.lastListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                String lastMsg = null;
                Long ts = null;
                String sender = null;

                for (DataSnapshot ds : snapshot.getChildren()) {
                    lastMsg = ds.child("message").getValue(String.class);
                    ts = ds.child("timestamp").getValue(Long.class);
                    sender = ds.child("sender").getValue(String.class);
                }

                t.lastMsg = (lastMsg == null ? "" : lastMsg);
                t.lastTs = ts;
                t.lastSender = (sender == null ? "" : sender);

                updateRowTexts(t);
                rebuildListUI();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        t.lastQuery.addValueEventListener(t.lastListener);
    }

    // ambil lastSeen penjual untuk tiap room
    private void attachSeenListener(@NonNull ThreadInfo t) {
        if (t.seenRef != null && t.seenListener != null) return;

        t.seenRef = chatRootRef.child(t.roomId)
                .child("_meta")
                .child("seen")
                .child(penjualId);

        t.seenListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                Long seen = snapshot.getValue(Long.class);
                t.lastSeenTs = seen;
                updateRowTexts(t);
                rebuildListUI();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        t.seenRef.addValueEventListener(t.seenListener);
    }

    // =========================
    // NOTIF HP (NEW): pakai pola temanmu tapi FIX agar tidak ke-_meta dan selaras penjual
    // =========================
    private void attachPhoneNotifListener(@NonNull ThreadInfo t) {
        if (t.notifQuery != null && t.notifListener != null) return;

        // baseline: ambil last notified dari SharedPreferences
        t.lastNotifiedTs = getSharedPreferences(SP_NAME, MODE_PRIVATE)
                .getLong("last_notif_" + t.roomId, 0L);

        // baseline tambahan: set ke pesan terakhir saat ini supaya tidak notif pesan lama
        chatRootRef.child(t.roomId)
                .orderByChild("timestamp")
                .limitToLast(1)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        Long ts = null;
                        for (DataSnapshot ds : snap.getChildren()) {
                            ts = ds.child("timestamp").getValue(Long.class);
                        }
                        if (ts != null && ts > t.lastNotifiedTs) {
                            t.lastNotifiedTs = ts;
                            saveLastNotified(t.roomId, t.lastNotifiedTs);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { }
                });

        // Listener notif: pesan terbaru realtime
        t.notifQuery = chatRootRef.child(t.roomId)
                .orderByChild("timestamp")
                .limitToLast(1);

        t.notifListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot msg, String prev) {

                String sender = msg.child("sender").getValue(String.class);
                String text = msg.child("message").getValue(String.class);
                Long ts = msg.child("timestamp").getValue(Long.class);

                // kalau bukan node message valid, skip
                if (sender == null || text == null || ts == null) return;

                // 1) penjual jangan NOTIF pesan sendiri
                if (SELLER_SENDER.equalsIgnoreCase(sender)) return;

                // 2) jangan notif kalau ini pesan lama / sudah pernah notif
                if (ts <= t.lastNotifiedTs) return;

                // 3) follow pola temanmu: gunakan read flag khusus penjual
                //    (kalau belum ada di DB, fallback ke seen timestamp)
                Boolean readPen = msg.child("read_penjual").getValue(Boolean.class);
                if (readPen != null && readPen) {
                    t.lastNotifiedTs = ts;
                    saveLastNotified(t.roomId, t.lastNotifiedTs);
                    return;
                }

                long seen = (t.lastSeenTs == null) ? 0L : t.lastSeenTs;
                if (ts <= seen) {
                    t.lastNotifiedTs = ts;
                    saveLastNotified(t.roomId, t.lastNotifiedTs);
                    return;
                }

                // === SHOW NOTIFICATION ===
                t.lastNotifiedTs = ts;
                saveLastNotified(t.roomId, t.lastNotifiedTs);
                showNotification(t, text);
            }

            @Override public void onChildChanged(@NonNull DataSnapshot snapshot, String prev) { }
            @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
            @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String prev) { }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };

        t.notifQuery.addChildEventListener(t.notifListener);
    }

    private void saveLastNotified(@NonNull String roomId, long ts) {
        getSharedPreferences(SP_NAME, MODE_PRIVATE)
                .edit()
                .putLong("last_notif_" + roomId, ts)
                .apply();
    }

    // =========================
    // UI Builder
    // =========================
    private LinearLayout createThreadRowView(@NonNull ThreadInfo t) {
        // Wrapper vertical (row + divider)
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setBackgroundColor(Color.parseColor("#FFF3E0"));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(72)
        );
        row.setLayoutParams(rowLp);

        // Avatar
        ImageView avatar = new ImageView(this);
        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        avLp.setMargins(0, 0, dp(12), 0);
        avatar.setLayoutParams(avLp);
        avatar.setPadding(dp(6), dp(6), dp(6), dp(6));

        // Anda bisa ganti drawable sesuai kebutuhan
        avatar.setImageResource(t.isAdmin ? R.drawable.pengguna_lakilaki : R.drawable.sister);

        // Info (name + preview)
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        );
        info.setLayoutParams(infoLp);

        TextView tvName = new TextView(this);
        tvName.setTextColor(Color.parseColor("#000000"));
        tvName.setTextSize(15);
        tvName.setTypeface(tvName.getTypeface(), android.graphics.Typeface.BOLD);

        TextView tvPreview = new TextView(this);
        tvPreview.setTextColor(Color.parseColor("#666666"));
        tvPreview.setTextSize(13);

        info.addView(tvName);
        info.addView(tvPreview);

        // Date + Dot (kanan)
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        right.setLayoutParams(rightLp);

        TextView tvDate = new TextView(this);
        tvDate.setTextColor(Color.parseColor("#777777"));
        tvDate.setTextSize(10);

        // titik merah kecil di bawah tanggal
        View dot = new View(this);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(7), dp(7));
        dotLp.topMargin = dp(4);
        dotLp.gravity = Gravity.END;
        dot.setLayoutParams(dotLp);

        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Color.parseColor("#E53935")); // merah
        dot.setBackground(dotBg);

        dot.setVisibility(View.GONE); // default hidden

        right.addView(tvDate);
        right.addView(dot);

        // Simpan refs
        t.tvName = tvName;
        t.tvPreview = tvPreview;
        t.tvDate = tvDate;
        t.dotView = dot;

        row.addView(avatar);
        row.addView(info);
        row.addView(right);

        // Click -> buka chat dalam + mark as read
        row.setOnClickListener(v -> {
            markThreadAsSeen(t);

            Intent intent = new Intent(isichat_admin_penjual2.this, isichat_admin_penjual.class);
            intent.putExtra("penjualId", penjualId);
            intent.putExtra("pembeliId", t.otherId);
            intent.putExtra("pembeliName", (t.displayName == null || t.displayName.trim().isEmpty())
                    ? (t.isAdmin ? "Admin" : "Pembeli")
                    : t.displayName);
            startActivity(intent);
        });

        // Divider
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(1)
        ));
        divider.setBackgroundColor(Color.parseColor("#DDDDDD"));

        wrapper.addView(row);
        wrapper.addView(divider);

        updateRowTexts(t);
        return wrapper;
    }

    // set lastSeen ke Firebase agar dot hilang
    private void markThreadAsSeen(@NonNull ThreadInfo t) {
        DatabaseReference ref = chatRootRef.child(t.roomId)
                .child("_meta")
                .child("seen")
                .child(penjualId);

        long now = System.currentTimeMillis();
        long last = (t.lastTs == null) ? 0L : t.lastTs;
        long mark = Math.max(now, last);

        ref.setValue(mark);
    }

    private void updateRowTexts(@NonNull ThreadInfo t) {
        if (t.tvName != null) {
            String nm = (t.displayName != null && !t.displayName.trim().isEmpty())
                    ? t.displayName
                    : (t.isAdmin ? "Admin" : "Pembeli");
            t.tvName.setText(nm);
        }

        if (t.tvPreview != null) {
            String pv = (t.lastMsg != null && !t.lastMsg.trim().isEmpty())
                    ? t.lastMsg
                    : "Menunggu pesan...";
            t.tvPreview.setText(pv);
        }

        if (t.tvDate != null) {
            String d = (t.lastTs != null) ? formatDate(t.lastTs) : "";
            t.tvDate.setText(d);
        }

        updateUnreadDot(t);
    }

    // tampilkan dot jika ada pesan baru dari lawan chat yang belum dibaca penjual
    private void updateUnreadDot(@NonNull ThreadInfo t) {
        if (t.dotView == null) return;

        long last = (t.lastTs == null) ? 0L : t.lastTs;
        long seen = (t.lastSeenTs == null) ? 0L : t.lastSeenTs;

        boolean fromOther = true;
        if (t.lastSender != null && !t.lastSender.trim().isEmpty()) {
            fromOther = !t.lastSender.equalsIgnoreCase(SELLER_SENDER);
        }

        boolean unread = fromOther && (last > seen);
        t.dotView.setVisibility(unread ? View.VISIBLE : View.GONE);
    }

    private void rebuildListUI() {
        if (listContainer == null) return;

        List<ThreadInfo> list = new ArrayList<>(threadMap.values());

        // Sort: Admin pinned -> terbaru
        Collections.sort(list, (o1, o2) -> {
            if (o1.isAdmin && !o2.isAdmin) return -1;
            if (!o1.isAdmin && o2.isAdmin) return 1;

            long t1 = (o1.lastTs == null) ? 0L : o1.lastTs;
            long t2 = (o2.lastTs == null) ? 0L : o2.lastTs;
            return Long.compare(t2, t1);
        });

        listContainer.removeAllViews();
        for (ThreadInfo t : list) {
            if (t.wrapper != null) listContainer.addView(t.wrapper);
        }
    }

    // =========================
    // Name resolver (Admin/Pembeli) -> tampilkan "Nama"
    // =========================
    private interface NameCallback { void onName(String name); }

    private void resolveUserName(@NonNull String uid, boolean isAdmin, @NonNull NameCallback cb) {
        String group = isAdmin ? "Admin" : "Pembeli";

        FirebaseDatabase.getInstance()
                .getReference("Users")
                .child(group)
                .child(uid)
                .child("nama")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name = snapshot.getValue(String.class);
                        if (name != null && !name.trim().isEmpty()) {
                            cb.onName(name.trim());
                        } else {
                            cb.onName(isAdmin ? "Admin" : "Pembeli");
                        }
                    }

                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        cb.onName(isAdmin ? "Admin" : "Pembeli");
                    }
                });
    }

    private boolean isAdminId(@NonNull String otherId) {
        String x = otherId.toLowerCase();
        return otherId.equalsIgnoreCase(ADMIN_ID) || x.contains("admin");
    }

    private String formatDate(long ts) {
        return new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(ts));
    }

    private String buildRoomId(@NonNull String penjualId, @NonNull String otherId) {
        return (penjualId.compareTo(otherId) < 0)
                ? (penjualId + "_" + otherId)
                : (otherId + "_" + penjualId);
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }

    // =========================
    // Model
    // =========================
    private static class ThreadInfo {
        String roomId;
        String otherId;
        boolean isAdmin;

        String displayName;
        String lastMsg;
        Long lastTs;

        // untuk deteksi unread
        String lastSender;
        Long lastSeenTs;

        // View refs
        LinearLayout wrapper;
        TextView tvName, tvPreview, tvDate;
        View dotView;

        // Listener refs (last msg)
        Query lastQuery;
        ValueEventListener lastListener;

        // seen listener
        DatabaseReference seenRef;
        ValueEventListener seenListener;

        // NOTIF HP (NEW)
        Query notifQuery;
        ChildEventListener notifListener;
        long lastNotifiedTs = 0L;

        ThreadInfo(String roomId, String otherId, boolean isAdmin) {
            this.roomId = roomId;
            this.otherId = otherId;
            this.isAdmin = isAdmin;
        }
    }
}
