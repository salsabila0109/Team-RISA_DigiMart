package com.example.digimart;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class tambahslot extends AppCompatActivity {

    EditText edtNomorSlot, edtIdSlot;
    Button btnSimpanSlot;
    ImageView btnBack;

    DatabaseReference refSlot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_slot);

        edtNomorSlot = findViewById(R.id.edtNomorSlot);
        edtIdSlot = findViewById(R.id.edtIdSlot);
        btnSimpanSlot = findViewById(R.id.btnSimpanSlot);
        btnBack = findViewById(R.id.btnBack);

        // BACA DATA KE "Slots"
        refSlot = FirebaseDatabase.getInstance().getReference("Slots");

        // Tombol kembali
        btnBack.setOnClickListener(v -> finish());

        // Tombol simpan
        btnSimpanSlot.setOnClickListener(v -> {

            String nomorSlot = edtNomorSlot.getText().toString().trim();
            String idToko = edtIdSlot.getText().toString().trim();

            if (nomorSlot.isEmpty() || idToko.isEmpty()) {
                Toast.makeText(tambahslot.this,
                        "Isi semua field terlebih dahulu!", Toast.LENGTH_SHORT).show();
                return;
            }

            String slotKey = "slot" + nomorSlot; // contoh: slot5

            HashMap<String, Object> data = new HashMap<>();
            data.put("idSlot", idToko);
            data.put("status", "Kosong");
            data.put("pemilik", "-");
            data.put("namaToko", "-");
            data.put("kategori", "-");
            data.put("phone", "-");

            refSlot.child(slotKey).setValue(data)
                    .addOnSuccessListener(aVoid -> {

                        // === ⭐️ Perintah penting, supaya AdminActivity langsung refresh ===
                        Intent result = new Intent();
                        result.putExtra("refresh", true);
                        setResult(RESULT_OK, result);
                        finish();

                        // ==================================================================

                        Toast.makeText(tambahslot.this,
                                "Slot berhasil ditambahkan!", Toast.LENGTH_SHORT).show();

                        finish();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(tambahslot.this,
                                    "Gagal menyimpan! " + e.getMessage(), Toast.LENGTH_LONG).show()
                    );
        });
    }
}
