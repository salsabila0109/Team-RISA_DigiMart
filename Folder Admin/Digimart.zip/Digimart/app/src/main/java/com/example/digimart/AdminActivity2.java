package com.example.digimart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminActivity2 extends AppCompatActivity {

    TextView tabSlotToko, tabAkunPenjual;
    ImageView iconChat;
    LinearLayout containerPenjual;

    DatabaseReference refToko;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin2);

        tabSlotToko = findViewById(R.id.tabSlotToko);
        tabAkunPenjual = findViewById(R.id.tabAkunPenjual);
        iconChat = findViewById(R.id.iconChat);
        containerPenjual = findViewById(R.id.containerPenjual);

        refToko = FirebaseDatabase.getInstance().getReference("Penjual");

        // ============= FIX: Tidak kembali ke AdminActivity =============
        tabSlotToko.setOnClickListener(v -> {
            // Tidak pindah halaman, tetap di sini
        });

        iconChat.setOnClickListener(v ->
                startActivity(new Intent(AdminActivity2.this, Chat_Admin.class)));

        loadSemuaToko();
    }


    private void loadSemuaToko() {

        refToko.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                containerPenjual.removeAllViews();

                for (DataSnapshot tokoSnap : snapshot.getChildren()) {

                    String keyToko = tokoSnap.getKey();

                    String namaToko = tokoSnap.child("namaToko").getValue(String.class);
                    String pemilik = tokoSnap.child("pemilik").getValue(String.class);
                    String kontak = tokoSnap.child("kontak").getValue(String.class);
                    String deskripsi = tokoSnap.child("deskripsi").getValue(String.class);
                    String status = tokoSnap.child("status").getValue(String.class);
                    String fotoBase64 = tokoSnap.child("fotoTokoBase64").getValue(String.class);

                    // ===== AMBIL KATEGORI =====
                    String kategori = "-";
                    if (tokoSnap.child("kategori").exists()) {

                        String k0 = tokoSnap.child("kategori").child("0").getValue(String.class);
                        String k1 = tokoSnap.child("kategori").child("1").getValue(String.class);

                        if (k0 != null && k1 != null)
                            kategori = k0 + ", " + k1;
                        else if (k0 != null)
                            kategori = k0;
                        else if (k1 != null)
                            kategori = k1;
                    }

                    // ===== FINAL DATA =====
                    final String fKey = keyToko;
                    final String fNama = namaToko != null ? namaToko : "-";
                    final String fPemilik = pemilik != null ? pemilik : "-";
                    final String fKontak = kontak != null ? kontak : "-";
                    final String fKategori = kategori;
                    final String fDeskripsi = deskripsi != null ? deskripsi : "-";
                    final String fFoto = fotoBase64;
                    final String fStatus = status != null ? status : "TUTUP";

                    // Inflate card toko
                    View card = LayoutInflater.from(AdminActivity2.this)
                            .inflate(R.layout.item_penjual, containerPenjual, false);

                    // Binding UI item_penjual
                    CardView cardView = (CardView) card;
                    TextView tvNama = card.findViewById(R.id.namaToko);
                    TextView tvPemilik = card.findViewById(R.id.pemilik);
                    TextView tvKontak = card.findViewById(R.id.kontak);
                    TextView tvStatus = card.findViewById(R.id.statusToko);
                    ImageView ivIcon = card.findViewById(R.id.iconToko);
                    Button btnDetail = card.findViewById(R.id.btnDetail);

                    // Set teks
                    tvNama.setText(fNama);
                    tvPemilik.setText("Pemilik: " + fPemilik);
                    tvKontak.setText("Kontak: " + fKontak);

                    // ============ STATUS BUKA =============
                    if (fStatus.equalsIgnoreCase("BUKA")) {

                        tvStatus.setText("Buka");
                        tvStatus.setTextColor(Color.parseColor("#2E7D32")); // hijau tua

                        ivIcon.setImageResource(R.drawable.slotterisi);
                        ivIcon.setColorFilter(Color.parseColor("#4CAF50")); // hijau icon

                        cardView.setCardBackgroundColor(Color.WHITE);

                        btnDetail.setBackgroundTintList(
                                ColorStateList.valueOf(Color.parseColor("#2E7D32"))
                        );

                    }
                    // ============ STATUS TUTUP =============
                    else {

                        tvStatus.setText("Tutup");
                        tvStatus.setTextColor(Color.parseColor("#E65100")); // oranye

                        ivIcon.setImageResource(R.drawable.icon_mart_tutup);
                        ivIcon.setColorFilter(Color.parseColor("#E65100"));

                        cardView.setCardBackgroundColor(Color.WHITE);

                        btnDetail.setBackgroundTintList(
                                ColorStateList.valueOf(Color.parseColor("#E65100"))
                        );
                    }

                    // ========= BUTTON DETAIL =========
                    btnDetail.setOnClickListener(v -> {
                        Intent i = new Intent(AdminActivity2.this, detail_pemilik_toko.class);

                        i.putExtra("keyToko", fKey);
                        i.putExtra("namaToko", fNama);
                        i.putExtra("pemilik", fPemilik);
                        i.putExtra("telepon", fKontak);
                        i.putExtra("kategori", fKategori);
                        i.putExtra("deskripsi", fDeskripsi);
                        i.putExtra("fotoBase64", fFoto);
                        i.putExtra("status", fStatus);

                        startActivity(i);
                    });

                    // TAMBAHKAN KE LAYOUT
                    containerPenjual.addView(card);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}
