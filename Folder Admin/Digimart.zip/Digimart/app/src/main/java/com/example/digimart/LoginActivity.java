package com.example.digimart;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.graphics.Typeface;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;

    DatabaseReference usersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnlogin);

        // 🔥 Bikin teks di EditText jadi BOLD (pasti berhasil)
        etUsername.setTypeface(null, Typeface.BOLD);
        etPassword.setTypeface(null, Typeface.BOLD);

        usersRef = FirebaseDatabase.getInstance().getReference("Users");

        // 🔥 Tambahkan admin default
        addAdminManually();

        btnLogin.setOnClickListener(v -> login());
    }

    // 🔥 Tambahkan admin langsung
    private void addAdminManually() {
        HelperClass admin = new HelperClass("admin", "1234");
        usersRef.child("admin").setValue(admin);
    }

    private void login() {
        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString();

        if (username.equals("admin") && password.equals("1234")) {
            Toast.makeText(this, "Login Admin Berhasil!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, AdminActivity.class));
        } else {
            Toast.makeText(this, "Login gagal!", Toast.LENGTH_SHORT).show();
        }
    }
}
