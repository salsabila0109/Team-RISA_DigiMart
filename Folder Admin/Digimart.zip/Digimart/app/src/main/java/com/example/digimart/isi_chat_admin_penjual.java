package com.example.digimart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class isi_chat_admin_penjual extends AppCompatActivity {

    ImageView btnBack;
    LinearLayout chatContainer;
    EditText edtMessage;
    ImageButton btnSend;

    // POPUP SLOT
    LinearLayout popupKonfirmasi;
    EditText edtIdSlot, edtPassword, edtKonfirmasiPassword;
    Button btnTerimaSlot, btnKonfirmasiSlot;

    NestedScrollView scrollView;

    DatabaseReference messagesRef;

    TextView tvHeaderName;

    String roomId = "";
    String uidPembeli = "";
    String nomorSlot = "";

    boolean isBantuan = false;
    String namaUser = "Pengguna";

    // NEW: untuk bedakan chat_pp vs chat_admin
    boolean isChatPP = false;

    // NEW: samakan dengan penjual (kalau adminId kamu beda, ganti)
    private static final String ADMIN_ID = "ADMIN001";
    private LinearLayout barPengajuan;
    private boolean isPenjualChat = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_admin_penjual);

        // LAYOUT NAIK SAAT KEYBOARD MUNCUL
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        );

        // INIT
        btnBack = findViewById(R.id.btnBack);
        chatContainer = findViewById(R.id.chatContainer);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);
        scrollView = findViewById(R.id.scrollViewChat);
        tvHeaderName = findViewById(R.id.tvHeaderName);

        popupKonfirmasi = findViewById(R.id.popupKonfirmasi);
        edtIdSlot = findViewById(R.id.edtIdSlot);
        edtPassword = findViewById(R.id.edtPassword);
        edtKonfirmasiPassword = findViewById(R.id.edtKonfirmasiPassword);
        btnTerimaSlot = findViewById(R.id.btnTerimaSlot);
        btnKonfirmasiSlot = findViewById(R.id.btnKonfirmasiSlot);
        barPengajuan = findViewById(R.id.barPengajuan);

        roomId = getIntent().getStringExtra("roomId");
        if (roomId == null) roomId = "";

// 1) CHAT BANTUAN (pembeli)
        if (roomId.startsWith("CHAT_BANTUAN_")) {

            isBantuan = true;
            isPenjualChat = false;

            uidPembeli = roomId.replace("CHAT_BANTUAN_", "");

            messagesRef = FirebaseDatabase.getInstance()
                    .getReference("chat_bantuan")
                    .child(roomId);

            // BAR SLOT: jangan tampil
            if (barPengajuan != null) barPengajuan.setVisibility(View.GONE);
            btnTerimaSlot.setVisibility(View.GONE);

// 2) CHAT PENJUAL ↔ ADMIN (chat_pp) roomId: "10111_ADMIN001" / "ADMIN001_10111"
        } else if (isChatPPRoomWithAdmin(roomId)) {

            isBantuan = false;
            isPenjualChat = true;

            uidPembeli = extractNonAdminId(roomId); // di sini uidPembeli = idSlot penjual (contoh 10111)
            nomorSlot = ""; // tidak ada slot pengajuan

            messagesRef = FirebaseDatabase.getInstance()
                    .getReference("chat_pp")
                    .child(roomId);

            // BAR SLOT: jangan tampil
            if (barPengajuan != null) barPengajuan.setVisibility(View.GONE);
            btnTerimaSlot.setVisibility(View.GONE);

// 3) PENGAJUAN SLOT (chat_admin) -> BAR SLOT boleh tampil
        } else {

            isBantuan = false;
            isPenjualChat = false;

            String[] arr = roomId.split("_");
            // format lama kamu: ADMIN_001_UID_SLOT_04 (pastikan indexnya benar sesuai milikmu)
            uidPembeli = arr[2];
            nomorSlot = arr[4];

            messagesRef = FirebaseDatabase.getInstance()
                    .getReference("chat_admin")
                    .child(roomId);

            // BAR SLOT: tampil
            if (barPengajuan != null) barPengajuan.setVisibility(View.VISIBLE);
            btnTerimaSlot.setVisibility(View.VISIBLE);
        }

        loadUserName();
        listenChat();

        btnSend.setOnClickListener(v -> sendChat());
        btnBack.setOnClickListener(v -> finish());

        // POPUP TERIMA SLOT (hanya mode lama, bukan bantuan & bukan chat_pp)
        btnTerimaSlot.setOnClickListener(v -> {
            if (isBantuan || isChatPP) return;

            popupKonfirmasi.setVisibility(View.VISIBLE);

            FirebaseDatabase.getInstance()
                    .getReference("Slots")
                    .child("slot" + nomorSlot)
                    .child("idSlot")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override public void onDataChange(@NonNull DataSnapshot ds) {
                            edtIdSlot.setText(ds.getValue(String.class));
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {}
                    });
        });

        btnKonfirmasiSlot.setOnClickListener(v -> konfirmasiSlot());
    }

    private boolean isChatPPRoomWithAdmin(@NonNull String roomId) {
        String[] p = roomId.split("_");
        if (p.length != 2) return false;
        return p[0].equalsIgnoreCase(ADMIN_ID) || p[1].equalsIgnoreCase(ADMIN_ID);
    }

    private String extractNonAdminId(@NonNull String roomId) {
        String[] p = roomId.split("_");
        if (p.length != 2) return "";
        if (p[0].equalsIgnoreCase(ADMIN_ID)) return p[1];
        if (p[1].equalsIgnoreCase(ADMIN_ID)) return p[0];
        return p[0];
    }

    // NEW
    private boolean isTwoPartRoom(@NonNull String rid) {
        String[] p = rid.split("_");
        return p.length == 2 && !p[0].trim().isEmpty() && !p[1].trim().isEmpty();
    }

    private void loadUserName() {

        FirebaseDatabase.getInstance()
                .getReference("Users")
                .child("Pembeli")
                .child(uidPembeli)
                .child("nama")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.exists()) {
                            namaUser = snapshot.getValue(String.class);
                            setHeaderTitle();
                        } else {

                            FirebaseDatabase.getInstance()
                                    .getReference("Users")
                                    .child("Penjual")
                                    .child(uidPembeli)
                                    .child("nama")
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override public void onDataChange(@NonNull DataSnapshot snapshot2) {
                                            if (snapshot2.exists()) {
                                                namaUser = snapshot2.getValue(String.class);
                                            } else {
                                                // fallback: tampilkan uidPembeli saja
                                                namaUser = uidPembeli;
                                            }
                                            setHeaderTitle();
                                        }
                                        @Override public void onCancelled(@NonNull DatabaseError error) {
                                            namaUser = uidPembeli;
                                            setHeaderTitle();
                                        }
                                    });
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        namaUser = uidPembeli;
                        setHeaderTitle();
                    }
                });
    }

    private void setHeaderTitle() {
        if (isBantuan) {
            tvHeaderName.setText(namaUser + " (Bantuan)");
        } else if (isChatPP) {
            // chat_pp tidak punya nomorSlot, jadi nama saja
            tvHeaderName.setText(namaUser);
        } else {
            tvHeaderName.setText(namaUser + " (Pengajuan Slot " + nomorSlot + ")");
        }
    }

    private void listenChat() {
        messagesRef.orderByChild("timestamp")
                .addValueEventListener(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {

                        chatContainer.removeAllViews();

                        for (DataSnapshot ds : snapshot.getChildren()) {

                            // NEW: skip meta
                            if ("_meta".equals(ds.getKey())) continue;

                            String sender = ds.child("sender").getValue(String.class);
                            String msg = ds.child("message").getValue(String.class);

                            if (sender == null) sender = "";
                            if (msg == null) msg = "";

                            if ("admin".equals(sender)) addBubbleRight(msg);
                            else addBubbleLeft(msg);

                            // tandai dibaca admin (biar kompatibel dua versi field)
                            ds.getRef().child("readByAdmin").setValue(true);
                            ds.getRef().child("read_admin").setValue(true);
                        }

                        autoScroll();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void sendChat() {

        String msg = edtMessage.getText().toString().trim();
        if (msg.isEmpty()) return;

        String id = messagesRef.push().getKey();
        if (id == null) return;

        HashMap<String, Object> data = new HashMap<>();
        data.put("sender", "admin");
        data.put("message", msg);
        data.put("timestamp", System.currentTimeMillis());

        // biar lintas app aman
        data.put("readByAdmin", true);
        data.put("read_admin", true);

        // lawan chat dianggap belum baca
        data.put("readByPembeli", false);
        data.put("read_pembeli", false);
        data.put("readByPenjual", false);
        data.put("read_penjual", false);

        messagesRef.child(id).setValue(data);

        edtMessage.setText("");
    }

    private void konfirmasiSlot() {

        String idSlot = edtIdSlot.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();
        String confirm = edtKonfirmasiPassword.getText().toString().trim();

        if (!password.equals(confirm)) {
            Toast.makeText(this, "Password tidak sama!", Toast.LENGTH_SHORT).show();
            return;
        }

        String pesan =
                "Pengajuan Slot " + nomorSlot + " diterima.\n" +
                        "ID Slot : " + idSlot + "\n" +
                        "Password : " + password;

        sendSlotMessage(pesan);

        // ===============================
        // 1. UPDATE SLOT
        // ===============================
        DatabaseReference slotRef = FirebaseDatabase.getInstance()
                .getReference("Slots")
                .child("slot" + nomorSlot);

        slotRef.child("idSlot").setValue(idSlot);
        slotRef.child("password").setValue(password);
        slotRef.child("pemilik").setValue(uidPembeli);
        slotRef.child("status").setValue("Terisi");

        DatabaseReference userRef = FirebaseDatabase.getInstance()
                .getReference("Users");

        // ===============================
        // 2. PEMBELI -> PENJUAL
        // ===============================
        userRef.child("Pembeli").child(uidPembeli)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (!snapshot.exists()) return;

                        Map<String, Object> data = (Map<String, Object>) snapshot.getValue();
                        data.put("password", password);
                        data.put("idSlot", idSlot);

                        userRef.child("Penjual").child(uidPembeli).setValue(data);
                        userRef.child("Pembeli").child(uidPembeli).removeValue();

                        // ===============================
                        // 3. SIMPAN AKUN LOGIN PENJUAL
                        // Users/penjual/{idSlot}
                        // ===============================
                        DatabaseReference akunLoginRef = FirebaseDatabase.getInstance()
                                .getReference("Users")
                                .child("penjual")
                                .child(idSlot);

                        HashMap<String, Object> akunLogin = new HashMap<>();
                        akunLogin.put("idSlot", idSlot);
                        akunLogin.put("password", password);

                        akunLoginRef.setValue(akunLogin);

                    }

                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });

        popupKonfirmasi.setVisibility(View.GONE);
    }

    private void sendSlotMessage(String pesan) {

        String id = messagesRef.push().getKey();
        if (id == null) return;

        HashMap<String, Object> msg = new HashMap<>();
        msg.put("sender", "admin");
        msg.put("message", pesan);
        msg.put("timestamp", System.currentTimeMillis());
        msg.put("readByPembeli", false);
        msg.put("readByAdmin", true);

        // tambahan biar kompatibel lintas app
        msg.put("read_admin", true);
        msg.put("read_pembeli", false);
        msg.put("read_penjual", false);

        messagesRef.child(id).setValue(msg);
    }

    private void addBubbleLeft(String pesan) {

        TextView tv = new TextView(this);
        tv.setText(pesan);
        tv.setPadding(22, 18, 22, 18);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(22f);
        bg.setColor(Color.WHITE);

        tv.setBackground(bg);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

        lp.gravity = Gravity.START;
        lp.setMargins(0, 10, 80, 10);

        tv.setLayoutParams(lp);
        chatContainer.addView(tv);
    }

    private void addBubbleRight(String pesan) {

        TextView tv = new TextView(this);
        tv.setText(pesan);
        tv.setPadding(22, 18, 22, 18);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(22f);
        bg.setColor(Color.parseColor("#FFCCBC"));

        tv.setBackground(bg);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

        lp.gravity = Gravity.END;
        lp.setMargins(80, 10, 0, 10);

        tv.setLayoutParams(lp);
        chatContainer.addView(tv);
    }

    private void autoScroll() {
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }
}
