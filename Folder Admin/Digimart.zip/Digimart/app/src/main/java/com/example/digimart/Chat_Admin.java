package com.example.digimart;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class Chat_Admin extends AppCompatActivity {

    ImageView btnBack;
    LinearLayout chatListContainer;

    DatabaseReference refSlotChat, refBantuanChat;

    // NEW: chat penjual-admin ada di chat_pp
    DatabaseReference refPPChat;

    ArrayList<ChatRoomModel> allRooms = new ArrayList<>();

    // NEW: samakan dengan yang dipakai penjual
    private static final String ADMIN_ID = "ADMIN001";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_admin);

        btnBack = findViewById(R.id.btnBack);
        chatListContainer = findViewById(R.id.chatListContainer);

        refSlotChat = FirebaseDatabase.getInstance().getReference("chat_admin");
        refBantuanChat = FirebaseDatabase.getInstance().getReference("chat_bantuan");

        // NEW
        refPPChat = FirebaseDatabase.getInstance().getReference("chat_pp");

        loadAllRooms();

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadAllRooms() {

        allRooms.clear();

        // 1️⃣ Load CHAT SLOT (chat_admin)
        refSlotChat.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot slotSnap) {

                for (DataSnapshot room : slotSnap.getChildren()) {

                    String roomId = room.getKey();
                    if (roomId == null) continue;

                    long lastTs = 0;
                    String lastMsg = "";

                    for (DataSnapshot msg : room.getChildren()) {
                        if ("_meta".equals(msg.getKey())) continue; // aman
                        Long ts = msg.child("timestamp").getValue(Long.class);
                        String msgTxt = msg.child("message").getValue(String.class);

                        if (ts != null && ts > lastTs) {
                            lastTs = ts;
                            lastMsg = msgTxt;
                        }
                    }

                    allRooms.add(new ChatRoomModel(roomId, lastMsg, lastTs));
                }

                // 2️⃣ Load CHAT BANTUAN
                refBantuanChat.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot bantuanSnap) {

                        for (DataSnapshot room : bantuanSnap.getChildren()) {

                            String roomId = room.getKey();
                            if (roomId == null) continue;

                            long lastTs = 0;
                            String lastMsg = "";

                            for (DataSnapshot msg : room.getChildren()) {
                                if ("_meta".equals(msg.getKey())) continue; // aman
                                Long ts = msg.child("timestamp").getValue(Long.class);
                                String msgTxt = msg.child("message").getValue(String.class);

                                if (ts != null && ts > lastTs) {
                                    lastTs = ts;
                                    lastMsg = msgTxt;
                                }
                            }

                            allRooms.add(new ChatRoomModel(roomId, lastMsg, lastTs));
                        }

                        // 3️⃣ NEW: Load CHAT PENJUAL-ADMIN dari chat_pp (contoh: 10111_ADMIN001)
                        refPPChat.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot ppSnap) {

                                for (DataSnapshot room : ppSnap.getChildren()) {

                                    String roomId = room.getKey();
                                    if (roomId == null) continue;

                                    // hanya room yang melibatkan admin
                                    if (!isRoomForThisAdmin(roomId)) continue;

                                    long lastTs = 0;
                                    String lastMsg = "";

                                    for (DataSnapshot msg : room.getChildren()) {
                                        if ("_meta".equals(msg.getKey())) continue;
                                        Long ts = msg.child("timestamp").getValue(Long.class);
                                        String msgTxt = msg.child("message").getValue(String.class);

                                        if (ts != null && ts > lastTs) {
                                            lastTs = ts;
                                            lastMsg = msgTxt;
                                        }
                                    }

                                    allRooms.add(new ChatRoomModel(roomId, lastMsg, lastTs));
                                }

                                // Sort chat dari terbaru
                                Collections.sort(allRooms,
                                        (a, b) -> Long.compare(b.lastTimestamp, a.lastTimestamp));

                                renderRooms();
                            }

                            @Override public void onCancelled(@NonNull DatabaseError error) {}
                        });
                    }

                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });

            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // NEW: room admin-penjual format 2 part: A_B
    private boolean isTwoPartRoom(String roomId) {
        String[] p = roomId.split("_");
        return p.length == 2 && p[0] != null && p[1] != null
                && !p[0].trim().isEmpty() && !p[1].trim().isEmpty();
    }

    // NEW: hanya masukkan room chat_pp yang berisi ADMIN_ID
    private boolean isRoomForThisAdmin(String roomId) {
        if (!isTwoPartRoom(roomId)) return false;
        String[] p = roomId.split("_");
        return p[0].equalsIgnoreCase(ADMIN_ID) || p[1].equalsIgnoreCase(ADMIN_ID);
    }

    private void renderRooms() {

        chatListContainer.removeAllViews();

        for (ChatRoomModel room : allRooms) {

            View item = LayoutInflater.from(this)
                    .inflate(R.layout.item_chat_admin, chatListContainer, false);

            TextView tvName = item.findViewById(R.id.tvName);
            TextView tvPreview = item.findViewById(R.id.tvPreview);
            TextView tvDate = item.findViewById(R.id.tvDate);

            // ====== NEW: kalau ini room chat_pp (penjual-admin), ambil nama toko dari node Penjual/{idSlot}/namaToko
            if (isTwoPartRoom(room.roomId)) {
                String penjualIdSlot = extractUid(room.roomId); // non-admin part

                FirebaseDatabase.getInstance().getReference("Penjual")
                        .child(penjualIdSlot)
                        .child("namaToko")
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                                String namaToko = snap.getValue(String.class);
                                if (namaToko == null || namaToko.trim().isEmpty()) {
                                    namaToko = "Penjual Slot " + penjualIdSlot;
                                }
                                tvName.setText(namaToko + " (Chat Penjual)");
                            }
                            @Override public void onCancelled(@NonNull DatabaseError error) {
                                tvName.setText("Penjual Slot " + penjualIdSlot + " (Chat Penjual)");
                            }
                        });

            } else {
                // ====== KODE LAMA (tetap): ambil nama user dari Users/Pembeli atau Users/Penjual
                String uid = extractUid(room.roomId);

                FirebaseDatabase.getInstance().getReference("Users")
                        .child("Pembeli")
                        .child(uid)
                        .child("nama")
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override public void onDataChange(@NonNull DataSnapshot snap) {

                                String nama = snap.getValue(String.class);

                                if (nama == null) {
                                    // cek penjual
                                    FirebaseDatabase.getInstance().getReference("Users")
                                            .child("Penjual")
                                            .child(uid)
                                            .child("nama")
                                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override public void onDataChange(@NonNull DataSnapshot snap2) {
                                                    String nama2 = snap2.getValue(String.class);
                                                    setNameBasedOnRoom(tvName, room.roomId, nama2);
                                                }

                                                @Override public void onCancelled(@NonNull DatabaseError error) {}
                                            });
                                } else {
                                    setNameBasedOnRoom(tvName, room.roomId, nama);
                                }
                            }

                            @Override public void onCancelled(@NonNull DatabaseError error) {}
                        });
            }

            tvPreview.setText(room.lastMessage);
            tvDate.setText(formatDate(room.lastTimestamp));

            item.setOnClickListener(v -> {
                Intent i = new Intent(Chat_Admin.this, isi_chat_admin_penjual.class);
                i.putExtra("roomId", room.roomId);
                startActivity(i);
            });

            chatListContainer.addView(item);
        }
    }

    private void setNameBasedOnRoom(TextView tv, String roomId, String nama) {

        if (nama == null || nama.trim().isEmpty()) nama = "Pengguna";

        if (roomId.startsWith("CHAT_BANTUAN_")) {
            tv.setText(nama + " (Bantuan)");
        } else {
            String slot = extractSlot(roomId);
            tv.setText(nama + " (Pengajuan Slot " + slot + ")");
        }
    }

    // Extract UID dari roomId
    private String extractUid(String roomId) {

        if (roomId.startsWith("CHAT_BANTUAN_")) {
            return roomId.replace("CHAT_BANTUAN_", "");
        }

        // NEW: chat_pp -> roomId "10111_ADMIN001" => return "10111" (yang bukan admin)
        if (isTwoPartRoom(roomId)) {
            String[] p = roomId.split("_");
            if (p[0].equalsIgnoreCase(ADMIN_ID)) return p[1];
            if (p[1].equalsIgnoreCase(ADMIN_ID)) return p[0];
            return p[0]; // fallback
        }

        // ADMIN_001_UID_SLOT_04 → UID = index 2 (kode lama)
        String[] p = roomId.split("_");
        return p[2];
    }

    // Extract nomor slot
    private String extractSlot(String roomId) {
        return roomId.substring(roomId.lastIndexOf("_") + 1);
    }

    // Format tanggal
    private String formatDate(long ts) {
        if (ts == 0) return "";
        return new SimpleDateFormat("dd/MM", Locale.getDefault())
                .format(new Date(ts));
    }

    // MODEL
    public static class ChatRoomModel {
        public String roomId;
        public String lastMessage;
        public long lastTimestamp;

        public ChatRoomModel(String id, String msg, long ts) {
            roomId = id;
            lastMessage = msg;
            lastTimestamp = ts;
        }
    }
}
