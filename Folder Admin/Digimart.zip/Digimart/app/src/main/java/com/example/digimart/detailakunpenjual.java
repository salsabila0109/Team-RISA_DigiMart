package com.example.digimart;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

class DetailAkunPenjualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_akun_penjual);
    }
}
