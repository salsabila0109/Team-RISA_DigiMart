package com.example.digimart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class detail_pemilik_toko extends AppCompatActivity {

    TextView txtNamaToko, txtPemilik, txtSlot, txtTelepon, txtKategori;
    Button btnStatus, btnKosongkan;
    ImageView btnBack, fotoTokoDetail;

    DatabaseReference refToko;
    String keyToko = "";  // ID Slot

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pemilik_toko);

        txtNamaToko = findViewById(R.id.NamaToko);
        txtPemilik = findViewById(R.id.Pemilik);
        txtSlot = findViewById(R.id.Slot);
        txtTelepon = findViewById(R.id.Telepon);
        txtKategori = findViewById(R.id.Kategori);

        btnStatus = findViewById(R.id.btnStatus);
        btnKosongkan = findViewById(R.id.btnKosongkan);
        btnBack = findViewById(R.id.btnBack);
        fotoTokoDetail = findViewById(R.id.fotoTokoDetail);

        keyToko = getIntent().getStringExtra("keyToko");
        if (keyToko == null) keyToko = "";

        txtSlot.setText("ID Slot: " + keyToko);

        refToko = FirebaseDatabase.getInstance()
                .getReference("Penjual")
                .child(keyToko);

        btnBack.setOnClickListener(v -> finish());

        loadDetailToko();

        btnStatus.setOnClickListener(v -> toggleStatus());

        btnKosongkan.setOnClickListener(v -> kosongkanToko());
    }

    private void loadDetailToko() {

        refToko.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (!snapshot.exists()) {
                    Toast.makeText(detail_pemilik_toko.this, "Data tidak ditemukan!", Toast.LENGTH_SHORT).show();
                    return;
                }

                String namaToko = snapshot.child("namaToko").getValue(String.class);
                txtNamaToko.setText(namaToko != null ? namaToko : "-");

                String pemilik = snapshot.child("pemilik").getValue(String.class);
                txtPemilik.setText("Pemilik: " + (pemilik != null ? pemilik : "-"));

                String telepon = snapshot.child("kontak").getValue(String.class);
                txtTelepon.setText("Telepon: " + (telepon != null ? telepon : "-"));

                String kategori = "-";
                if (snapshot.child("kategori").exists()) {
                    StringBuilder builder = new StringBuilder();
                    for (DataSnapshot kat : snapshot.child("kategori").getChildren()) {
                        String val = kat.getValue(String.class);
                        if (val != null) {
                            if (builder.length() > 0) builder.append(", ");
                            builder.append(val);
                        }
                    }
                    kategori = builder.toString();
                }

                txtKategori.setText("Kategori: " + kategori);

                String status = snapshot.child("status").getValue(String.class);
                if (status == null) status = "TUTUP";

                btnStatus.setText(status);
                btnStatus.setTextColor(
                        status.equalsIgnoreCase("BUKA")
                                ? getColor(android.R.color.holo_green_dark)
                                : getColor(android.R.color.holo_red_dark)
                );

                String fotoBase64 = snapshot.child("fotoTokoBase64").getValue(String.class);
                if (fotoBase64 != null && !fotoBase64.isEmpty()) {
                    try {
                        byte[] decoded = Base64.decode(fotoBase64, Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                        fotoTokoDetail.setImageBitmap(bitmap);
                    } catch (Exception ignored) {}
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void toggleStatus() {
        refToko.child("status").get().addOnSuccessListener(snapshot -> {

            String now = snapshot.getValue(String.class);
            if (now == null) now = "TUTUP";

            String newStatus = now.equals("BUKA") ? "TUTUP" : "BUKA";

            refToko.child("status").setValue(newStatus);
        });
    }

    // ================================================================
// FINAL KOSONGKAN SLOT SESUAI PERMINTAAN
// ================================================================
    private void kosongkanToko() {

        // 1. Hapus data toko di /Penjual/{keyToko}
        refToko.removeValue().addOnSuccessListener(aVoid -> {

            // ================================
            // 2. CARI SLOT MANA YANG PUNYA idSlot = keyToko
            // ================================
            DatabaseReference slotsRef = FirebaseDatabase.getInstance()
                    .getReference("Slots");

            slotsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot slotSnap : snapshot.getChildren()) {

                        String idSlot = slotSnap.child("idSlot").getValue(String.class);

                        if (idSlot != null && idSlot.equals(keyToko)) {

                            // INI SLOT YANG BENAR! RESET DI SINI
                            slotSnap.getRef().child("status").setValue("Kosong");
                            slotSnap.getRef().child("namaToko").setValue("-");
                            slotSnap.getRef().child("password").setValue("-");
                            slotSnap.getRef().child("pemilik").setValue("-");
                            slotSnap.getRef().child("kategori").setValue("-");
                            slotSnap.getRef().child("phone").setValue("-");

                            break;
                        }
                    }

                    // 3. Hapus akun dari Users/Penjual/{id}
                    DatabaseReference usersPenjualRef = FirebaseDatabase.getInstance()
                            .getReference("Users")
                            .child("Penjual")
                            .child(keyToko);
                    usersPenjualRef.removeValue();

                    // 4. Hapus akun dari Users/penjual/{id}
                    DatabaseReference usersPenjual2 = FirebaseDatabase.getInstance()
                            .getReference("Users")
                            .child("penjual")
                            .child(keyToko);
                    usersPenjual2.removeValue();

                    // 5. Hapus akun dari AkunPenjual/{id}
                    DatabaseReference akunRef = FirebaseDatabase.getInstance()
                            .getReference("AkunPenjual")
                            .child(keyToko);
                    akunRef.removeValue();

                    Toast.makeText(detail_pemilik_toko.this,
                            "Slot berhasil dikosongkan! Status berubah menjadi Kosong.",
                            Toast.LENGTH_SHORT).show();

                    finish();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        });
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
