package com.example.digimart;

public class SlotModel {
    public String idSlot;
    public String namaSlot;
    public String status;
    public String gambar;

    public SlotModel() {}

    public SlotModel(String idSlot, String namaSlot, String status, String gambar) {
        this.idSlot = idSlot;
        this.namaSlot = namaSlot;
        this.status = status;
        this.gambar = gambar;
    }

    public String getIdSlot() { return idSlot; }
    public String getNamaSlot() { return namaSlot; }
    public String getStatus() { return status; }
    public String getGambar() { return gambar; }

    public void setIdSlot(String idSlot) { this.idSlot = idSlot; }
    public void setNamaSlot(String namaSlot) { this.namaSlot = namaSlot; }
    public void setStatus(String status) { this.status = status; }
    public void setGambar(String gambar) { this.gambar = gambar; }
}
