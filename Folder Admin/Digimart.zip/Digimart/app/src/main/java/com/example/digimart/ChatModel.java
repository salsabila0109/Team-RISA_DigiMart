package com.example.digimart;

public class ChatModel {
    public String sender;
    public String message;
    public long timestamp;
    public boolean read_admin; // ← BARU

    public ChatModel() { }

    public ChatModel(String sender, String message, long timestamp, boolean read_admin) {
        this.sender = sender;
        this.message = message;
        this.timestamp = timestamp;
        this.read_admin = read_admin;
    }
}
