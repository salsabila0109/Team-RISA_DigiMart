package com.example.digimart;

public class ChatRoomModel {
    public String roomId;
    public long lastTimestamp;

    public ChatRoomModel(String roomId, long lastTimestamp) {
        this.roomId = roomId;
        this.lastTimestamp = lastTimestamp;
    }
}
