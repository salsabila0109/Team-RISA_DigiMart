package com.example.digimart;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SlotAdapter extends RecyclerView.Adapter<SlotAdapter.ViewHolder> {

    Context context;
    ArrayList<SlotModel> list;

    public SlotAdapter(Context context, ArrayList<SlotModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_item_slot, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        SlotModel slot = list.get(position);

        // Ambil key slot → example: slot01
        String slotKey = slot.getIdSlot();

        // Default tampilan
        String slotNamePretty = slotKey;

        // Convert "slot01" → "Slot 01"
        if (slotKey != null && slotKey.startsWith("slot")) {
            String num = slotKey.substring(4);  // hasil: 01
            slotNamePretty = "Slot " + num;     // hasil: Slot 01
        }

        holder.txtSlot.setText(slotNamePretty);

        // ==============================
        // STATUS
        // ==============================
        String status = slot.getStatus() != null ? slot.getStatus() : "";
        String gambar = slot.getGambar() != null ? slot.getGambar() : "";

        // ==============================
        // STATUS TERISI (HIJAU)
        // ==============================
        if (status.equalsIgnoreCase("Terisi")) {

            holder.txtStatus.setText("Status: Terisi");
            holder.txtStatus.setTextColor(Color.parseColor("#4CAF50"));

            holder.imgStatus.setImageResource(R.drawable.slotterisi);
            holder.imgStatus.setColorFilter(Color.parseColor("#4CAF50"));

            holder.txtPemilik.setVisibility(View.GONE);

            holder.btnDetail.setVisibility(View.VISIBLE);
            holder.btnDetail.setBackgroundTintList(
                    ColorStateList.valueOf(Color.parseColor("#2E7D32"))
            );
        }

        // ==============================
        // STATUS KOSONG (ORANYE)
        // ==============================
        else {

            holder.txtStatus.setText("Status: Kosong");
            holder.txtStatus.setTextColor(Color.parseColor("#F44336"));

            holder.imgStatus.setImageResource(R.drawable.slotkosong);
            holder.imgStatus.setColorFilter(Color.parseColor("#FF5722"));

            holder.txtPemilik.setVisibility(View.GONE);
            holder.btnDetail.setVisibility(View.GONE);
        }

        // ==============================
        // TOMBOL DETAIL
        // ==============================
        holder.btnDetail.setOnClickListener(v -> {
            Intent i = new Intent(context, detail_pemilik_toko.class);
            i.putExtra("keyToko", slot.getIdSlot());
            i.putExtra("namaToko", slot.getNamaSlot());
            context.startActivity(i);
        });

        // ==============================
        // KLIK CARD
        // ==============================
        holder.card.setOnClickListener(v -> {
            if (status.equalsIgnoreCase("Terisi")) {
                Intent i = new Intent(context, detail_pemilik_toko.class);
                i.putExtra("keyToko", slot.getIdSlot());
                i.putExtra("namaToko", slot.getNamaSlot());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgStatus;
        TextView txtSlot, txtStatus, txtPemilik;
        Button btnDetail;
        CardView card;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgStatus = itemView.findViewById(R.id.imgStatus);
            txtSlot = itemView.findViewById(R.id.txtSlot);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            txtPemilik = itemView.findViewById(R.id.txtPemilik);
            btnDetail = itemView.findViewById(R.id.btnDetail);
            card = itemView.findViewById(R.id.cardSlot);
        }
    }
}
