package com.example.digimart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminActivity extends AppCompatActivity {

    TextView tabSlotToko, tabAkunPenjual;
    FloatingActionButton fabAdd;
    RecyclerView recyclerSlot;

    SlotAdapter adapter;
    ArrayList<SlotModel> listSlot;

    DatabaseReference slotRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // ======== BINDING UI ========
        tabSlotToko = findViewById(R.id.tabSlotToko);
        tabAkunPenjual = findViewById(R.id.tabAkunPenjual);
        fabAdd = findViewById(R.id.fabAdd);
        recyclerSlot = findViewById(R.id.recyclerSlot);

        // ======== RECYCLER VIEW SETUP ========
        recyclerSlot.setLayoutManager(new GridLayoutManager(this, 2));

        listSlot = new ArrayList<>();
        adapter = new SlotAdapter(this, listSlot);
        recyclerSlot.setAdapter(adapter);

        // ======== FIREBASE REFERENCE ========
        slotRef = FirebaseDatabase.getInstance().getReference("Slots");

        // ======== LOAD DATA ========
        loadAllSlots();

        // ======== NAVIGASI KE LIST PENJUAL ========
        tabAkunPenjual.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, AdminActivity2.class);
            startActivity(i);
        });

        // ======== FAB TAMBAH SLOT ========
        fabAdd.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, tambahslot.class);
            startActivityForResult(i, 100);
        });
    }


    // ========================================
    // MUAT SEMUA SLOT DARI FIREBASE
    // ========================================
    private void loadAllSlots() {
        slotRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                listSlot.clear();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    SlotModel model = ds.getValue(SlotModel.class);

                    if (model != null) {
                        model.setIdSlot(ds.getKey());   // ★ AMBIL key Firebase → "slot01"
                        listSlot.add(model);
                    }
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminActivity.this,
                        "Gagal memuat data: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    // ========================================
    // KETIKA TAMBAH SLOT SELESAI
    // ========================================
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == 100 && res == RESULT_OK) {
            loadAllSlots();
        }
    }

    // ========================================
    // BACK TIDAK PERNAH KEMBALI KE LOGIN
    // ========================================
    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        // Tekan BACK → aplikasi minimize
        moveTaskToBack(true);
    }
}
