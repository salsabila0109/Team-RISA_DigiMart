package com.example.digimart;
public class ModelSlot {

    public String nomorSlot;
    public String idSlot;
    public String status;
    public String pemilik;
    public String namaToko;
    public String kategori;
    public String phone;

    public ModelSlot() {} // wajib untuk Firebase

    public ModelSlot(String nomorSlot, String idSlot, String status,
                     String pemilik, String namaToko, String kategori, String phone) {
        this.nomorSlot = nomorSlot;
        this.idSlot = idSlot;
        this.status = status;
        this.pemilik = pemilik;
        this.namaToko = namaToko;
        this.kategori = kategori;
        this.phone = phone;
    }
}
