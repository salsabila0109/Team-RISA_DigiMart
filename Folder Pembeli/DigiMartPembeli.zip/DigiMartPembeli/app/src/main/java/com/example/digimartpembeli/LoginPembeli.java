package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginPembeli extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnMasukPembeli;
    private TextView tvDaftar;

    // Firebase Auth instance
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pembeli);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnMasukPembeli = findViewById(R.id.btnMasukPembeli);
        tvDaftar = findViewById(R.id.tvDaftar);

        // Inisialisasi FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        btnMasukPembeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Validasi input
                if (TextUtils.isEmpty(email)) {
                    etEmail.setError("Email wajib diisi");
                    etEmail.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    etPassword.setError("Password wajib diisi");
                    etPassword.requestFocus();
                    return;
                }

                // Login pakai Firebase
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(LoginPembeli.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(LoginPembeli.this, "Login sukses", Toast.LENGTH_SHORT).show();

                                    Intent intent = new Intent(LoginPembeli.this, DashboardPembeli2.class);
                                    // Hapus semua activity sebelumnya supaya back tidak kembali ke DashboardPembeli
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    // Login gagal
                                    Toast.makeText(LoginPembeli.this,
                                            "Gagal login: " + task.getException().getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });

        tvDaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginPembeli.this, DaftarPembeli.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
