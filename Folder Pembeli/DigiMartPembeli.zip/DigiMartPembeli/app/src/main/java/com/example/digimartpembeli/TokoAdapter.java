package com.example.digimartpembeli;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TokoAdapter extends RecyclerView.Adapter<TokoAdapter.ViewHolder> {

    public interface OnTokoClickListener {
        void onClick(Toko toko);
    }

    private List<Toko> tokoList;
    private OnTokoClickListener listener;

    public TokoAdapter(List<Toko> tokoList, OnTokoClickListener listener) {
        this.tokoList = tokoList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_toko, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Toko t = tokoList.get(position);

        h.namaToko.setText(t.getNamaToko());
        h.pemilik.setText("Pemilik : " + t.getPemilik());
        h.kontak.setText("Kontak : " + t.getKontak());
        h.deskripsi.setText(t.getDeskripsi());

        if ("BUKA".equalsIgnoreCase(t.getStatus())) {
            h.badgeStatus.setText("BUKA");
            h.badgeStatus.setTextColor(0xFF2E7D32);
        } else {
            h.badgeStatus.setText("TUTUP");
            h.badgeStatus.setTextColor(0xFFC62828);
        }

        try {
            String foto = t.getFotoTokoBase64();

            if (foto != null && !foto.trim().isEmpty() && foto.length() > 20) {
                byte[] decode = Base64.decode(foto, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decode, 0, decode.length);
                h.imgToko.setImageBitmap(bmp);
            } else {
                // FOTO KOSONG → jangan set drawable, biarkan background circle_mask
                h.imgToko.setImageBitmap(null);
            }

        } catch (Exception e) {
            h.imgToko.setImageBitmap(null); // fallback: biarkan circle_mask muncul
        }

        h.btnDetail.setOnClickListener(v -> {
            if (listener != null) {
                listener.onClick(t);  // KIRIM DATA TOKO KE ACTIVITY
            }
        });
    }

    @Override
    public int getItemCount() {
        return tokoList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgToko;
        TextView namaToko, pemilik, kontak, deskripsi, badgeStatus;
        AppCompatButton btnDetail;

        public ViewHolder(@NonNull View v) {
            super(v);
            imgToko = v.findViewById(R.id.imgToko);
            namaToko = v.findViewById(R.id.namaToko);
            pemilik = v.findViewById(R.id.pemilik);
            kontak = v.findViewById(R.id.kontak);
            deskripsi = v.findViewById(R.id.deskripsi);
            badgeStatus = v.findViewById(R.id.badgeStatus);
            btnDetail = v.findViewById(R.id.btnDetail);
        }
    }

    public void updateList(List<Toko> newList) {
        tokoList = newList;
        notifyDataSetChanged();
    }
}
