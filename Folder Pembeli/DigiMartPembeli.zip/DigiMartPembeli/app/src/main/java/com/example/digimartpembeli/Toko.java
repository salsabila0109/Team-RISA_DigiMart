package com.example.digimartpembeli;
import java.util.List;
import java.util.ArrayList;

public class Toko {
    private String id;
    private String namaToko;
    private String pemilik;
    private String kontak;
    private String deskripsi;
    private List<String> kategori;
    private String status;
    private String fotoTokoBase64;

    public Toko() {}

    public Toko(String namaToko, String pemilik, String kontak, String deskripsi,
                List<String> kategori, String status, String fotoTokoBase64) {
        this.namaToko = namaToko;
        this.pemilik = pemilik;
        this.kontak = kontak;
        this.deskripsi = deskripsi;
        this.kategori = kategori;
        this.status = status;
        this.fotoTokoBase64 = fotoTokoBase64;
    }
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNamaToko() { return namaToko; }
    public String getPemilik() { return pemilik; }
    public String getKontak() { return kontak; }
    public String getDeskripsi() { return deskripsi; }
    public List<String> getKategori() { return kategori; }
    public String getStatus() { return status; }
    public String getFotoTokoBase64() { return fotoTokoBase64; }
}
