package com.example.digimartpembeli;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class Chat extends AppCompatActivity {

    private ImageView btnBack;
    private LinearLayout listContainer;
    private String pembeliId;
    // Room yang sedang dibuka
    private String currentOpenRoomId = null;

    // Model sederhana untuk chat list
    private static class ChatItem {
        String name;
        String uid;
        String roomId;
        String lastMsg;
        long timestamp;
        String fotoBase64;
        boolean unread;
        View.OnClickListener listener;

        ChatItem(String name, String uid, String roomId, String lastMsg, long timestamp, String fotoBase64, View.OnClickListener listener) {
            this.name = name;
            this.uid = uid;
            this.roomId = roomId;
            this.lastMsg = lastMsg;
            this.timestamp = timestamp;
            this.fotoBase64 = fotoBase64;
            this.unread = false;
            this.listener = listener;
        }

        // === Constructor baru untuk chat bantuan (ADA unread) ===
        ChatItem(String name, String uid, String roomId, String lastMsg,
                 long timestamp, boolean unread, String fotoBase64,
                 View.OnClickListener listener) {

            this.name = name;
            this.uid = uid;
            this.roomId = roomId;
            this.lastMsg = lastMsg;
            this.timestamp = timestamp;
            this.unread = unread;  // 🔥 simpan nilai unread
            this.fotoBase64 = fotoBase64;
            this.listener = listener;
        }
    }

    // List global untuk semua chat
    private ArrayList<ChatItem> tokoChats = new ArrayList<>();
    private ArrayList<ChatItem> adminChats = new ArrayList<>();
    private ArrayList<ChatItem> slotChats = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        btnBack = findViewById(R.id.btnBack);
        listContainer = findViewById(R.id.listChatContainer);
        pembeliId = FirebaseAuth.getInstance().getUid();

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(0, 0);
        });

        loadAllChats();
    }

    private void loadAllChats() {
        loadTokoChats();
        loadAdminChats();
        loadSlotChats();
    }

    // ===== Load CHAT TOKO =====
    private void loadTokoChats() {
        DatabaseReference refToko = FirebaseDatabase.getInstance().getReference("chat_pp");
        refToko.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapToko) {
                tokoChats.clear();
                for (DataSnapshot roomSnap : snapToko.getChildren()) {
                    String roomId = roomSnap.getKey();
                    if (roomId == null || !roomId.contains(pembeliId)) continue;

                    String[] parts = roomId.split("_");
                    if (parts.length != 2) continue;

                    String penjualId = parts[0].equals(pembeliId) ? parts[1] : parts[0];

                    String lastMsg = "";
                    long lastTime = 0;
                    for (DataSnapshot msg : roomSnap.getChildren()) {
                        String tmpMsg = msg.child("message").getValue(String.class);
                        Long tmpTime = msg.child("timestamp").getValue(Long.class);
                        if (tmpMsg != null) lastMsg = tmpMsg;
                        if (tmpTime != null) lastTime = tmpTime;
                    }

                    DatabaseReference tokoDataRef = FirebaseDatabase.getInstance()
                            .getReference("Penjual")
                            .child(penjualId);

                    final String fLastMsg = lastMsg;
                    final long fLastTime = lastTime;

                    tokoDataRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot tokoSnap) {
                            String namaToko = tokoSnap.child("namaToko").getValue(String.class);
                            if (namaToko == null) namaToko = "Toko " + penjualId;

                            String fotoBase64 = tokoSnap.child("fotoTokoBase64").getValue(String.class);

                            // Update atau tambah chat toko
                            boolean found = false;
                            for (int i = 0; i < tokoChats.size(); i++) {
                                ChatItem item = tokoChats.get(i);
                                if (item.roomId.equals(roomId)) {
                                    item.lastMsg = fLastMsg;
                                    item.timestamp = fLastTime;
                                    item.name = namaToko;
                                    item.fotoBase64 = fotoBase64;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                final String finalRoomId = roomId;
                                tokoChats.add(new ChatItem(
                                        namaToko,
                                        penjualId,
                                        roomId,
                                        fLastMsg,
                                        fLastTime,
                                        fotoBase64,
                                        v -> {
                                            Intent i = new Intent(Chat.this, Chat_toko_pembeli.class);
                                            i.putExtra("TOKO_ID", penjualId);
                                            startActivityForResult(i, 1001);
                                            overridePendingTransition(0, 0);
                                            currentOpenRoomId = finalRoomId;
                                        }
                                ));
                            }

                            renderAllChats();
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {}
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    // ===== Load CHAT BANTUAN ADMIN =====
    private void loadAdminChats() {
        DatabaseReference refBantuan = FirebaseDatabase.getInstance()
                .getReference("chat_bantuan")
                .child("CHAT_BANTUAN_" + pembeliId);

        refBantuan.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapBantuan) {
                adminChats.clear();
                if (snapBantuan.exists()) {
                    String lastMsg = "";
                    long lastTime = 0;

                    boolean unread = false;

                    for (DataSnapshot msg : snapBantuan.getChildren()) {
                        Long tmpTime = msg.child("timestamp").getValue(Long.class);
                        String tmpMsg = msg.child("message").getValue(String.class);
                        Boolean rbp = msg.child("readByPembeli").getValue(Boolean.class);

                        if (tmpTime != null && tmpTime > lastTime) {
                            lastTime = tmpTime;
                            lastMsg = tmpMsg != null ? tmpMsg : "";
                        }

                        // 🔥 Kalau ada pesan admin yang belum dibaca → tampilkan dot merah
                        String sender = msg.child("sender").getValue(String.class);
                        if ("admin".equals(sender) && (rbp == null || !rbp)) {
                            unread = true;
                        }
                    }

                    adminChats.add(new ChatItem(
                            "Admin",
                            "admin",
                            "CHAT_BANTUAN_" + pembeliId,
                            lastMsg,
                            lastTime,
                            unread,
                            null,
                            v -> {
                                Intent i = new Intent(Chat.this, Chat_Bantuan.class);
                                startActivity(i);
                                overridePendingTransition(0, 0);
                            }
                    ));

                }
                renderAllChats();
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    // ===== Load CHAT PENGAJUAN SLOT =====
    private void loadSlotChats() {
        DatabaseReference refSlot = FirebaseDatabase.getInstance().getReference("chat_admin");
        refSlot.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapSlot) {
                slotChats.clear();
                for (DataSnapshot roomSnap : snapSlot.getChildren()) {
                    String roomId = roomSnap.getKey();
                    if (roomId == null || !roomId.contains(pembeliId)) continue;

                    String lastMsg = "";
                    long lastTime = 0;
                    for (DataSnapshot msg : roomSnap.getChildren()) {
                        String tmpMsg = msg.child("message").getValue(String.class);
                        Long tmpTime = msg.child("timestamp").getValue(Long.class);
                        if (tmpMsg != null) lastMsg = tmpMsg;
                        if (tmpTime != null) lastTime = tmpTime;
                    }

                    String nomorSlot = ambilNomorSlot(roomId);
                    final String finalRoomId = roomId;
                    slotChats.add(new ChatItem(
                            "Admin (Pengajuan Slot " + nomorSlot + ")",
                            "admin_slot_" + nomorSlot,
                            roomId,
                            lastMsg,
                            lastTime,
                            null,
                            v -> {
                                Intent i = new Intent(Chat.this, Cara_Pengajuan_Slot.class);
                                i.putExtra("SLOT_NOMOR", nomorSlot);
                                startActivityForResult(i, 1001);
                                overridePendingTransition(0, 0);
                                currentOpenRoomId = finalRoomId;
                            }
                    ));
                }
                renderAllChats();
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    // ===== Render Semua Chat =====
    private void renderAllChats() {
        ArrayList<ChatItem> allChats = new ArrayList<>();
        allChats.addAll(tokoChats);
        allChats.addAll(adminChats);
        allChats.addAll(slotChats);
        renderChatList(allChats);
    }

    private void renderChatList(ArrayList<ChatItem> chatItems) {
        // urutkan dari timestamp terbaru ke lama
        Collections.sort(chatItems, (a, b) -> Long.compare(b.timestamp, a.timestamp));

        listContainer.removeAllViews();

        for (ChatItem item : chatItems) {
            View view = getLayoutInflater().inflate(R.layout.item_chat_row, null);

            TextView tvNama = view.findViewById(R.id.tvNamaChat);
            TextView tvLast = view.findViewById(R.id.tvLastMsgChat);
            TextView tvDate = view.findViewById(R.id.tvDateChat);
            ImageView imgAvatar = view.findViewById(R.id.imgAvatarChat);
            ImageView imgDot = view.findViewById(R.id.imgDotChat);
            imgDot.setVisibility(View.GONE);

            tvNama.setText(item.name);
            tvLast.setText(item.lastMsg);

            String tanggal = item.timestamp > 0
                    ? new SimpleDateFormat("dd/MM", Locale.getDefault())
                    .format(new Date(item.timestamp))
                    : "";
            tvDate.setText(tanggal);

            Bitmap bmp;
            if (item.fotoBase64 != null && !item.fotoBase64.trim().isEmpty()) {
                try {
                    byte[] decodedString = Base64.decode(item.fotoBase64, Base64.DEFAULT);
                    bmp = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                } catch (Exception e) {
                    bmp = BitmapFactory.decodeResource(getResources(), R.drawable.profile2);
                }
            } else {
                bmp = BitmapFactory.decodeResource(getResources(), R.drawable.profile2);
            }
            imgAvatar.setImageBitmap(getCircularBitmap(bmp));

            view.setOnClickListener(v -> {
                currentOpenRoomId = item.roomId;
                markMessagesAsRead(item);
                if (item.listener != null) item.listener.onClick(v);
            });

            checkUnread(item, imgDot);

            listContainer.addView(view); // tambahkan di urutan array, karena sudah sorted
        }
    }


    private void markMessagesAsRead(ChatItem item) {
        DatabaseReference roomRef;
        if (item.roomId.startsWith("CHAT_BANTUAN_") || item.uid.equals("admin")) {
            roomRef = FirebaseDatabase.getInstance().getReference("chat_bantuan").child(item.roomId);
        } else if (item.uid.startsWith("admin_slot_")) {
            roomRef = FirebaseDatabase.getInstance().getReference("chat_admin").child(item.roomId);
        } else {
            roomRef = FirebaseDatabase.getInstance().getReference("chat_pp").child(item.roomId);
        }

        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);
                    if (!pembeliId.equals(sender) && !Boolean.TRUE.equals(readByPembeli)) {
                        ds.getRef().child("readByPembeli").setValue(true); // simpan di database
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    private void checkUnread(ChatItem item, ImageView imgDot) {

        if (item.roomId.equals(currentOpenRoomId)) {
            // Room sedang dibuka, dot tidak perlu muncul
            imgDot.setVisibility(View.GONE);
            return;
        }

        DatabaseReference roomRef;

        if (item.uid.equals("admin")) {
            // Chat bantuan admin
            roomRef = FirebaseDatabase.getInstance().getReference("chat_bantuan").child(item.roomId);
            roomRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    boolean hasUnread = false;
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String sender = ds.child("sender").getValue(String.class);
                        Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);

                        if (sender != null && sender.startsWith("admin") && (readByPembeli == null || !readByPembeli)) {
                            hasUnread = true;
                            break;
                        }
                    }
                    imgDot.setVisibility(hasUnread ? View.VISIBLE : View.GONE);
                }

                @Override
                public void onCancelled(DatabaseError error) {}
            });
        } else if (item.uid.startsWith("admin_slot_")) {
            // Chat pengajuan slot
            roomRef = FirebaseDatabase.getInstance().getReference("chat_admin").child(item.roomId);
            roomRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    boolean hasUnread = false;
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String sender = ds.child("sender").getValue(String.class);
                        Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);

                        if (sender != null && sender.startsWith("admin") && (readByPembeli == null || !readByPembeli)) {
                            hasUnread = true;
                            break;
                        }
                    }
                    imgDot.setVisibility(hasUnread ? View.VISIBLE : View.GONE);
                }

                @Override
                public void onCancelled(DatabaseError error) {}
            });
        } else {
            // Chat toko
            roomRef = FirebaseDatabase.getInstance().getReference("chat_pp").child(item.roomId);
            roomRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    boolean hasUnread = false;
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String sender = ds.child("sender").getValue(String.class);
                        Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);

                        // Hanya cek pesan dari penjual (bukan pembeli)
                        if (sender != null && !sender.equals(pembeliId) && (readByPembeli == null || !readByPembeli)) {
                            hasUnread = true;
                            break;
                        }
                    }
                    imgDot.setVisibility(hasUnread ? View.VISIBLE : View.GONE);
                }

                @Override
                public void onCancelled(DatabaseError error) {}
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1001) {
            currentOpenRoomId = null; // user keluar dari room
            loadAllChats(); // reload untuk update dot
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        currentOpenRoomId = null; // user tidak sedang membuka room
    }

    @Override
    protected void onPause() {
        super.onPause();
        currentOpenRoomId = null;
    }

    private String ambilNomorSlot(String roomId) {
        String[] parts = roomId.split("_");
        return parts.length >= 5 ? parts[4] : "";
    }

    private Bitmap getCircularBitmap(Bitmap bitmap) {
        int size = Math.min(bitmap.getWidth(), bitmap.getHeight());
        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);

        android.graphics.Canvas canvas = new android.graphics.Canvas(output);
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setAntiAlias(true);

        float radius = size / 2f;
        canvas.drawCircle(radius, radius, radius, paint);

        android.graphics.Rect srcRect = new android.graphics.Rect(
                (bitmap.getWidth() - size) / 2,
                (bitmap.getHeight() - size) / 2,
                (bitmap.getWidth() + size) / 2,
                (bitmap.getHeight() + size) / 2
        );
        android.graphics.Rect destRect = new android.graphics.Rect(0, 0, size, size);

        paint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, srcRect, destRect, paint);

        return output;
    }
}
