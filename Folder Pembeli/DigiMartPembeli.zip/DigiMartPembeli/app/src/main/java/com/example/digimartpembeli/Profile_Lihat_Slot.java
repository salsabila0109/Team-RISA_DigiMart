package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Profile_Lihat_Slot extends AppCompatActivity {

    private LinearLayout slotContainer; // Container slot dinamis
    private LinearLayout tabLikes, tabHome, tabProfile;
    private FrameLayout profileFloating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_lihat_slot);

        // LinearLayout dalam ScrollView sebagai tempat slot
        slotContainer = findViewById(R.id.slotContainer);

        // Bottom nav
        tabLikes = findViewById(R.id.tabLikes);
        tabHome = findViewById(R.id.tabHome);
        tabProfile = findViewById(R.id.tabProfile);
        profileFloating = findViewById(R.id.profileFloating);

        ImageView btnChat = findViewById(R.id.btnChat);
        btnChat.setOnClickListener(v -> {
            Intent intent = new Intent(Profile_Lihat_Slot.this, Chat.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        // === Bottom Nav Listeners ===
        tabLikes.setOnClickListener(v -> {
            startActivity(new Intent(Profile_Lihat_Slot.this, DaftarTokoSuka.class));
            overridePendingTransition(0, 0); // 🔥 transisi 0
            finish();
        });

        tabHome.setOnClickListener(v -> {
            startActivity(new Intent(Profile_Lihat_Slot.this, DashboardPembeli2.class));
            overridePendingTransition(0, 0); // 🔥 transisi 0
            finish();
        });

        View.OnClickListener goProfile = v -> {
            startActivity(new Intent(Profile_Lihat_Slot.this, ProfilePembeli.class));
            overridePendingTransition(0, 0); // 🔥 transisi 0
            finish();
        };
        tabProfile.setOnClickListener(goProfile);
        profileFloating.setOnClickListener(goProfile);

        // === Load slot dari Firebase ===
        loadSlotsFromFirebase();
    }

    private void loadSlotsFromFirebase() {
        DatabaseReference slotsRef = FirebaseDatabase.getInstance().getReference("Slots");

        slotsRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                slotContainer.removeAllViews(); // bersihkan dulu

                for (DataSnapshot slotSnapshot : task.getResult().getChildren()) {
                    Slot slot = slotSnapshot.getValue(Slot.class);
                    if (slot != null && "Kosong".equals(slot.getStatus())) {

                        // Ambil key: slot01, slot02, slot04
                        String key = slotSnapshot.getKey(); // "slot01"
                        String nomorSlot = key.replace("slot", ""); // "01", "02", "04"

                        // Inflate template
                        View slotCard = getLayoutInflater().inflate(R.layout.slot_card_template, null);

                        TextView tvSlotNomor = slotCard.findViewById(R.id.tvSlotNomor);
                        TextView tvSlotLabel = slotCard.findViewById(R.id.tvSlotLabel);
                        Button btnAjukan = slotCard.findViewById(R.id.btnAjukan);
                        LinearLayout slotNumberBox = slotCard.findViewById(R.id.slotNumberBox);

                        // Set teks dan background
                        tvSlotNomor.setText(nomorSlot); // lingkaran
                        tvSlotLabel.setText("Slot " + nomorSlot); // teks di atas tombol
                        slotNumberBox.setBackgroundResource(R.drawable.kartu_slot); // semua sama

                        // Tombol ajukan
                        btnAjukan.setOnClickListener(v -> {
                            Intent intent = new Intent(Profile_Lihat_Slot.this, Cara_Pengajuan_Slot.class);
                            intent.putExtra("SLOT_NOMOR", nomorSlot); // kirim nomor slot
                            startActivity(intent);
                        });

                        // Tambahkan ke container
                        slotContainer.addView(slotCard);
                    }
                }

            } else {
                Toast.makeText(this, "Gagal memuat slot", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
