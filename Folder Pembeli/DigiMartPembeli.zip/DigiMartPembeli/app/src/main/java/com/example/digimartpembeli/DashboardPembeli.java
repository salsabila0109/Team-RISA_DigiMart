package com.example.digimartpembeli;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.auth.FirebaseAuth;


import java.util.ArrayList;
import java.util.List;

public class DashboardPembeli extends AppCompatActivity {

    private EditText searchBar;
    private TextView btnLogin;
    private RecyclerView containerToko;
    private TokoAdapter adapter;

    private List<Toko> tokoList = new ArrayList<>();
    private List<Toko> tokoListFull = new ArrayList<>();

    LinearLayout tabSemua, tabMakanan, tabPakaian, tabAlat, tabMainan, tabLainnya;
    TextView textSemua, textMakanan, textPakaian, textAlat, textMainan, textLainnya;
    View lineSemua, lineMakanan, linePakaian, lineAlat, lineMainan, lineLainnya;

    private String kategoriDipilih = "Semua";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            // User masih login → langsung ke DashboardPembeli2
            startActivity(new Intent(DashboardPembeli.this, DashboardPembeli2.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_dashboard_pembeli);

        btnLogin = findViewById(R.id.btnLogin);
        searchBar = findViewById(R.id.searchBar);
        containerToko = findViewById(R.id.containerToko);

        containerToko.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TokoAdapter(tokoList, toko -> {
            Intent intent = new Intent(DashboardPembeli.this, Detail_Toko.class);

            intent.putExtra("TOKO_ID", toko.getId());
            intent.putExtra("NAMA_TOKO", toko.getNamaToko());
            intent.putExtra("PEMILIK", toko.getPemilik());
            intent.putExtra("KONTAK", toko.getKontak());
            intent.putExtra("DESKRIPSI", toko.getDeskripsi());

            // ubah List<String> menjadi ArrayList<String>
            if (toko.getKategori() != null) {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>(toko.getKategori()));
            } else {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>());
            }

            intent.putExtra("STATUS", toko.getStatus());
            intent.putExtra("FOTO", toko.getFotoTokoBase64());

            startActivity(intent);
        });

        containerToko.setAdapter(adapter);

        // ==== LOGIN BUTTON ====
        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardPembeli.this, LoginPembeli.class);
            startActivity(intent);
        });

        initTabs();
        loadTokoFromFirebase();
        setupSearch();
    }

    private void initTabs() {
        tabSemua = findViewById(R.id.tabSemua);
        tabMakanan = findViewById(R.id.tabMakanan);
        tabPakaian = findViewById(R.id.tabPakaian);
        tabAlat = findViewById(R.id.tabAlat);
        tabMainan = findViewById(R.id.tabMainan);
        tabLainnya = findViewById(R.id.tabLainnya);

        textSemua = findViewById(R.id.textSemua);
        textMakanan = findViewById(R.id.textMakanan);
        textPakaian = findViewById(R.id.textPakaian);
        textAlat = findViewById(R.id.textAlat);
        textMainan = findViewById(R.id.textMainan);
        textLainnya = findViewById(R.id.textLainnya);

        lineSemua = findViewById(R.id.lineSemua);
        lineMakanan = findViewById(R.id.lineMakanan);
        linePakaian = findViewById(R.id.linePakaian);
        lineAlat = findViewById(R.id.lineAlat);
        lineMainan = findViewById(R.id.lineMainan);
        lineLainnya = findViewById(R.id.lineLainnya);

        tabSemua.setOnClickListener(v -> setKategori("Semua"));
        tabMakanan.setOnClickListener(v -> setKategori("Makanan"));
        tabPakaian.setOnClickListener(v -> setKategori("Pakaian"));
        tabAlat.setOnClickListener(v -> setKategori("Alat"));
        tabMainan.setOnClickListener(v -> setKategori("Mainan"));
        tabLainnya.setOnClickListener(v -> setKategori("Lain"));

    }

    private void setKategori(String kategori) {
        kategoriDipilih = kategori;

        resetTabColors();
        switch (kategori) {
            case "Semua":
                textSemua.setTextColor(Color.parseColor("#FF5722"));
                lineSemua.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
            case "Makanan":
                textMakanan.setTextColor(Color.parseColor("#FF5722"));
                lineMakanan.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
            case "Pakaian":
                textPakaian.setTextColor(Color.parseColor("#FF5722"));
                linePakaian.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
            case "Alat":
                textAlat.setTextColor(Color.parseColor("#FF5722"));
                lineAlat.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
            case "Mainan":
                textMainan.setTextColor(Color.parseColor("#FF5722"));
                lineMainan.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
            case "Lain":
                textLainnya.setTextColor(Color.parseColor("#FF5722"));
                lineLainnya.setBackgroundColor(Color.parseColor("#FF5722"));
                break;
        }

        filterList();
    }

    private void resetTabColors() {
        textSemua.setTextColor(Color.parseColor("#616161"));
        textMakanan.setTextColor(Color.parseColor("#616161"));
        textPakaian.setTextColor(Color.parseColor("#616161"));
        textAlat.setTextColor(Color.parseColor("#616161"));
        textMainan.setTextColor(Color.parseColor("#616161"));
        textLainnya.setTextColor(Color.parseColor("#616161"));

        lineSemua.setBackgroundColor(Color.TRANSPARENT);
        lineMakanan.setBackgroundColor(Color.TRANSPARENT);
        linePakaian.setBackgroundColor(Color.TRANSPARENT);
        lineAlat.setBackgroundColor(Color.TRANSPARENT);
        lineMainan.setBackgroundColor(Color.TRANSPARENT);
        lineLainnya.setBackgroundColor(Color.TRANSPARENT);
    }

    private void setupSearch() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterList();
            }
        });
    }

    private void filterList() {
        String keyword = searchBar.getText().toString().toLowerCase();

        List<Toko> filtered = new ArrayList<>();
        for (Toko t : tokoListFull) {

            // Filter kategori (case-insensitive)
            boolean matchKategori = kategoriDipilih.equals("Semua");
            if (!matchKategori && t.getKategori() != null) {
                for (String k : t.getKategori()) {
                    if (k.equalsIgnoreCase(kategoriDipilih)) {
                        matchKategori = true;
                        break;
                    }
                }
            }

            // Filter nama toko
            boolean matchSearch = t.getNamaToko() != null && t.getNamaToko().toLowerCase().contains(keyword);

            if (matchKategori && matchSearch) {
                filtered.add(t);
            }
        }

        adapter.updateList(filtered);
    }

    private void loadTokoFromFirebase() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Penjual");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                tokoList.clear();
                tokoListFull.clear();

                for (DataSnapshot d : ds.getChildren()) {
                    Toko t = d.getValue(Toko.class);
                    if (t != null) {
                        tokoList.add(t);
                        tokoListFull.add(t);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }
}
