package com.example.digimartpembeli;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class Chat_toko_pembeli extends AppCompatActivity {

    private ImageView btnBack, imgAvatarToko;
    private TextView txtNamaToko, txtStatusToko;
    private ScrollView scrollView;
    private LinearLayout chatContainer;

    private EditText edtMessage;
    private ImageButton btnSend;

    private DatabaseReference roomRef;
    private ValueEventListener chatListener;

    private String penjualId; // bisa diganti sesuai toko yang diklik
    private String pembeliId;
    private final String myRole = "pembeli";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_toko_pembeli);

        // Ambil user login
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if(user != null){
            pembeliId = user.getUid(); // UID unik tiap pembeli
        } else {
            finish();
            return;
        }

        // ===== Ambil penjualId dari Intent =====
        Intent intent = getIntent();
        penjualId = intent.getStringExtra("TOKO_ID");
        if (penjualId == null || penjualId.isEmpty()) {
            finish(); // tidak ada toko, keluar
            return;
        }

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        // HEADER
        btnBack = findViewById(R.id.btnBack);
        imgAvatarToko = findViewById(R.id.imgAvatarToko);
        txtNamaToko = findViewById(R.id.txtNamaToko);
        txtStatusToko = findViewById(R.id.txtStatusToko);

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(0, 0);
        });

        loadTokoHeader();

        // ScrollView
        View root = findViewById(android.R.id.content);
        scrollView = findFirstScrollView(root);

        if (scrollView.getChildCount() > 0 && scrollView.getChildAt(0) instanceof LinearLayout) {
            chatContainer = (LinearLayout) scrollView.getChildAt(0);
        }
        chatContainer.removeAllViews();

        // Height ScrollView
        ViewGroup.LayoutParams pScroll = scrollView.getLayoutParams();
        if (pScroll instanceof LinearLayout.LayoutParams) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) pScroll;
            lp.height = 0;
            lp.weight = 1f;
            scrollView.setLayoutParams(lp);
        }

        // Input bar
        attachInputBar();

        // Firebase chat
        String roomId = buildRoomId(penjualId, pembeliId);
        roomRef = FirebaseDatabase.getInstance().getReference("chat_pp").child(roomId);
        listenChatRealtime();
    }
    private void markAllAsRead() {
        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()){
                    String sender = ds.child("sender").getValue(String.class);
                    Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);
                    if(!myRole.equals(sender) && (readByPembeli == null || !readByPembeli)) {
                        ds.getRef().child("readByPembeli").setValue(true);
                    }
                }
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void loadTokoHeader() {
        DatabaseReference tokoRef = FirebaseDatabase.getInstance().getReference("Penjual").child(penjualId);
        tokoRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String namaToko = snapshot.child("namaToko").getValue(String.class);
                    String fotoBase64 = snapshot.child("fotoTokoBase64").getValue(String.class);

                    if(namaToko != null) txtNamaToko.setText(namaToko);

                    if(fotoBase64 != null && !fotoBase64.isEmpty()){
                        try {
                            byte[] decodedString = Base64.decode(fotoBase64, Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                            RoundedBitmapDrawable roundedDrawable =
                                    RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                            roundedDrawable.setCircular(true);

                            imgAvatarToko.setImageDrawable(roundedDrawable);

                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }

                    // ===== Ambil info terakhir aktif =====
                    String roomId = buildRoomId(penjualId, pembeliId);
                    DatabaseReference chatRef = FirebaseDatabase.getInstance().getReference("chat_pp").child(roomId);
                    chatRef.orderByChild("timestamp").limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot chatSnap) {
                            long lastTimestamp = 0;
                            for (DataSnapshot msgSnap : chatSnap.getChildren()) {
                                String sender = msgSnap.child("sender").getValue(String.class);
                                Long ts = msgSnap.child("timestamp").getValue(Long.class);
                                if(sender != null && sender.equals("penjual") && ts != null) {
                                    lastTimestamp = ts;
                                }
                            }
                            if(lastTimestamp > 0){
                                long diffMillis = System.currentTimeMillis() - lastTimestamp;
                                long diffMinutes = diffMillis / (1000 * 60);
                                String statusText;
                                if(diffMinutes < 2){ // online threshold 2 menit
                                    statusText = "online";
                                } else if(diffMinutes < 60){
                                    statusText = diffMinutes + " menit yang lalu";
                                } else {
                                    long diffHours = diffMinutes / 60;
                                    statusText = diffHours + " jam yang lalu";
                                }
                                txtStatusToko.setText(statusText);
                            } else {
                                txtStatusToko.setText("offline");
                            }
                        }

                        @Override public void onCancelled(DatabaseError error) {}
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    private void attachInputBar() {
        ViewGroup content = findViewById(android.R.id.content);
        ViewGroup root = (ViewGroup) content.getChildAt(0);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(16, 12, 16, 12);
        bar.setBackgroundColor(Color.parseColor("#FFF8F0"));

        edtMessage = new EditText(this);
        edtMessage.setHint("Tulis pesan...");
        edtMessage.setMinLines(1);
        edtMessage.setMaxLines(4);
        edtMessage.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        edtMessage.setBackground(null);

        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        edtMessage.setLayoutParams(etLp);

        btnSend = new ImageButton(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setScaleType(ImageButton.ScaleType.CENTER);
        btnSend.setPadding(22,22,22,22);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(999f);
        bg.setColor(Color.parseColor("#FE5D26"));
        btnSend.setBackground(bg);

        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sendLp.setMargins(16,0,0,0);
        btnSend.setLayoutParams(sendLp);

        btnSend.setOnClickListener(v -> {
            String msg = edtMessage.getText().toString().trim();
            if(!msg.isEmpty()) {
                kirimChat(myRole, msg);
                edtMessage.setText("");
            }
        });

        bar.addView(edtMessage);
        bar.addView(btnSend);

        root.addView(bar);
    }

    private void listenChatRealtime() {
        Query q = roomRef.orderByChild("timestamp");

        chatListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                chatContainer.removeAllViews();

                for(DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    String message = ds.child("message").getValue(String.class);

                    if(sender == null) sender = "";
                    if(message == null) message = "";

                    if(myRole.equals(sender)) addBubbleRight(message);
                    else addBubbleLeft(message);
                }

                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));

                // ✅ Tandai semua pesan dari penjual sebagai read
                markRoomAsRead();
            }

            @Override public void onCancelled(DatabaseError error) {}
        };

        q.addValueEventListener(chatListener);
    }

    private void markRoomAsRead() {
        if(roomRef == null) return;

        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);
                    if(!myRole.equals(sender) && (readByPembeli == null || !readByPembeli)) {
                        ds.getRef().child("readByPembeli").setValue(true);
                    }
                }
            }

            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void kirimChat(String sender, String message) {
        String id = roomRef.push().getKey();
        if(id == null) return;

        Map<String,Object> data = new HashMap<>();
        data.put("sender", sender);
        data.put("message", message);
        data.put("timestamp", System.currentTimeMillis());
        data.put("readByPembeli", sender.equals("pembeli")); // otomatis true kalau pengirim pembeli

        roomRef.child(id).setValue(data);
    }


    private void addBubbleRight(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        tv.setPadding(22,16,22,16);

        GradientDrawable b = new GradientDrawable();
        b.setCornerRadius(24f);
        b.setColor(Color.parseColor("#FFCCBC"));
        tv.setBackground(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.END;
        lp.setMargins(70,12,0,12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    private void addBubbleLeft(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        tv.setPadding(22,16,22,16);

        GradientDrawable b = new GradientDrawable();
        b.setCornerRadius(24f);
        b.setColor(Color.WHITE);
        tv.setBackground(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        lp.setMargins(0,12,70,12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    private String buildRoomId(String penjualId, String pembeliId) {
        return (penjualId.compareTo(pembeliId) < 0) ? penjualId + "_" + pembeliId : pembeliId + "_" + penjualId;
    }

    private ScrollView findFirstScrollView(View root) {
        if(root instanceof ScrollView) return (ScrollView) root;
        if(root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for(int i=0;i<vg.getChildCount();i++){
                ScrollView r = findFirstScrollView(vg.getChildAt(i));
                if(r!=null) return r;
            }
        }
        return null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(roomRef!=null && chatListener!=null) roomRef.removeEventListener(chatListener);
    }
}
