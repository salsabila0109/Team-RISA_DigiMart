package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.ArrayList;

public class DashboardPembeli2 extends AppCompatActivity {

    private ImageView btnChat;
    private EditText searchBar;

    private RecyclerView recyclerToko;
    private TokoAdapter adapter;

    // List utama (asli dari Firebase)
    private List<Toko> tokoList = new ArrayList<>();

    // List aktif (setelah filter kategori/search)
    private List<Toko> filteredList = new ArrayList<>();

    // Bottom nav
    private LinearLayout tabLikes, tabProfile;
    private FrameLayout homeFloating;

    private TextView textAkunPenjual;

    // TAB KATEGORI
    private LinearLayout tabSemua, tabMakanan, tabPakaian, tabAlat, tabMainan, tabLainnya;
    private TextView textSemua, textMakanan, textPakaian, textAlat, textMainan, textLainnya;
    private View lineSemua, lineMakanan, linePakaian, lineAlat, lineMainan, lineLainnya;

    private String kategoriAktif = "Semua";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_pembeli2);

        initViews();
        setupBottomNav();
        setupHeader();
        setupRecyclerView();
        setupTabKategori();
        checkAkunStatus();
        setupSearchBar();
        setupBackPressHandler();
    }

    // ========================================
    private void initViews() {
        btnChat = findViewById(R.id.btnChat);
        searchBar = findViewById(R.id.searchBar);
        textAkunPenjual = findViewById(R.id.textAkunPenjual);

        recyclerToko = findViewById(R.id.containerToko);

        tabLikes = findViewById(R.id.tabLikes);
        tabProfile = findViewById(R.id.tabProfile);
        homeFloating = findViewById(R.id.homeFloating);

        tabSemua = findViewById(R.id.tabSemua);
        tabMakanan = findViewById(R.id.tabMakanan);
        tabPakaian = findViewById(R.id.tabPakaian);
        tabAlat = findViewById(R.id.tabAlat);
        tabMainan = findViewById(R.id.tabMainan);
        tabLainnya = findViewById(R.id.tabLainnya);

        textSemua = findViewById(R.id.textSemua);
        textMakanan = findViewById(R.id.textMakanan);
        textPakaian = findViewById(R.id.textPakaian);
        textAlat = findViewById(R.id.textAlat);
        textMainan = findViewById(R.id.textMainan);
        textLainnya = findViewById(R.id.textLainnya);

        lineSemua = findViewById(R.id.lineSemua);
        lineMakanan = findViewById(R.id.lineMakanan);
        linePakaian = findViewById(R.id.linePakaian);
        lineAlat = findViewById(R.id.lineAlat);
        lineMainan = findViewById(R.id.lineMainan);
        lineLainnya = findViewById(R.id.lineLainnya);
    }

    private void setupHeader() {
        btnChat.setOnClickListener(v -> {
            startActivity(new Intent(DashboardPembeli2.this, Chat.class));
            overridePendingTransition(0, 0);
        });
    }
    private void checkAkunStatus() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DatabaseReference refPembeli = FirebaseDatabase.getInstance().getReference("Users").child("Pembeli");
        DatabaseReference refPenjual = FirebaseDatabase.getInstance().getReference("Users").child("Penjual");

        // CEK DI PEMBELI
        refPembeli.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    // MASIH PEMBELI → lanjut load toko
                    loadTokoFromFirebase();
                } else {
                    // TIDAK ADA DI PEMBELI → cek apakah pindah ke PENJUAL
                    refPenjual.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snap2) {
                            if (snap2.exists()) {
                                // SUDAH JADI PENJUAL
                                recyclerToko.setVisibility(View.GONE);
                                textAkunPenjual.setVisibility(View.VISIBLE);
                            } else {
                                // UID tidak ada di Pembeli dan tidak ada di Penjual
                                recyclerToko.setVisibility(View.GONE);
                                textAkunPenjual.setText("Akun tidak ditemukan di sistem");
                                textAkunPenjual.setVisibility(View.VISIBLE);
                            }
                        }

                        @Override public void onCancelled(@NonNull DatabaseError error) {}
                    });
                }
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void setupRecyclerView() {
        adapter = new TokoAdapter(tokoList, toko -> {
            Intent intent = new Intent(DashboardPembeli2.this, Detail_Toko.class);

            intent.putExtra("TOKO_ID", toko.getId());
            intent.putExtra("NAMA_TOKO", toko.getNamaToko());
            intent.putExtra("PEMILIK", toko.getPemilik());
            intent.putExtra("KONTAK", toko.getKontak());
            intent.putExtra("DESKRIPSI", toko.getDeskripsi());

            // ubah List<String> menjadi ArrayList<String>
            if (toko.getKategori() != null) {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>(toko.getKategori()));
            } else {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>());
            }

            intent.putExtra("STATUS", toko.getStatus());
            intent.putExtra("FOTO", toko.getFotoTokoBase64());

            startActivity(intent);
            overridePendingTransition(0, 0);
        });


        recyclerToko.setLayoutManager(new LinearLayoutManager(this));
        recyclerToko.setAdapter(adapter);
    }

    // ============================================================
    // LOAD DATA
    // ============================================================
    private void loadTokoFromFirebase() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Penjual");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tokoList.clear();
                filteredList.clear();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    Toko toko = ds.getValue(Toko.class);
                    if (toko != null) {
                        toko.setId(ds.getKey()); // <-- tambahkan ini, simpan key Penjual
                        tokoList.add(toko);
                    }
                }

                filteredList.addAll(tokoList);
                adapter.updateList(filteredList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DashboardPembeli2.this,
                        "Gagal load toko: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // ============================================================
    // FILTER MASTER: Search + Kategori
    // ============================================================
    private void applyFilters() {

        String query = searchBar.getText().toString().toLowerCase();

        filteredList.clear();

        for (Toko t : tokoList) {

            boolean cocokKategori = kategoriAktif.equals("Semua");

            if (!cocokKategori && t.getKategori() != null) {
                for (String k : t.getKategori()) {
                    if (k.equalsIgnoreCase(kategoriAktif)) {
                        cocokKategori = true;
                        break;
                    }
                }
            }

            boolean cocokSearch =
                    t.getNamaToko() != null &&
                            t.getNamaToko().toLowerCase().contains(query);

            if (cocokKategori && cocokSearch) {
                filteredList.add(t);
            }
        }

        adapter.updateList(filteredList);
    }

    // ============================================================
    // SEARCH BAR
    // ============================================================
    private void setupSearchBar() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilters();
            }
        });
    }

    // ============================================================
    // TAB KATEGORI
    // ============================================================
    private void setupTabKategori() {
        selectTab("Semua");

        tabSemua.setOnClickListener(v -> {
            kategoriAktif = "Semua";
            selectTab("Semua");
            applyFilters();
        });

        tabMakanan.setOnClickListener(v -> {
            kategoriAktif = "Makanan";
            selectTab("Makanan");
            applyFilters();
        });

        tabPakaian.setOnClickListener(v -> {
            kategoriAktif = "Pakaian";
            selectTab("Pakaian");
            applyFilters();
        });

        tabAlat.setOnClickListener(v -> {
            kategoriAktif = "Alat";
            selectTab("Alat");
            applyFilters();
        });

        tabMainan.setOnClickListener(v -> {
            kategoriAktif = "Mainan";
            selectTab("Mainan");
            applyFilters();
        });
        tabLainnya.setOnClickListener(v -> {
            kategoriAktif = "Lain";
            selectTab("Lainnya");
            applyFilters();
        });
    }

    private void selectTab(String kategori) {

        textSemua.setTextColor(0xFF616161);
        textMakanan.setTextColor(0xFF616161);
        textPakaian.setTextColor(0xFF616161);
        textAlat.setTextColor(0xFF616161);
        textMainan.setTextColor(0xFF616161);
        textLainnya.setTextColor(0xFF616161);

        lineSemua.setBackgroundColor(0x00000000);
        lineMakanan.setBackgroundColor(0x00000000);
        linePakaian.setBackgroundColor(0x00000000);
        lineAlat.setBackgroundColor(0x00000000);
        lineMainan.setBackgroundColor(0x00000000);
        lineLainnya.setBackgroundColor(0x00000000);

        int orange = 0xFFFF5722;

        switch (kategori) {
            case "Semua":
                textSemua.setTextColor(orange);
                lineSemua.setBackgroundColor(orange);
                break;

            case "Makanan":
                textMakanan.setTextColor(orange);
                lineMakanan.setBackgroundColor(orange);
                break;

            case "Pakaian":
                textPakaian.setTextColor(orange);
                linePakaian.setBackgroundColor(orange);
                break;

            case "Alat":
                textAlat.setTextColor(orange);
                lineAlat.setBackgroundColor(orange);
                break;

            case "Mainan":
                textMainan.setTextColor(orange);
                lineMainan.setBackgroundColor(orange);
                break;

            case "Lainnya":
                textLainnya.setTextColor(orange);
                lineLainnya.setBackgroundColor(orange);
                break;
        }
    }

    private void setupBottomNav() {
        tabLikes.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardPembeli2.this, DaftarTokoSuka.class);
            startActivity(intent);
            overridePendingTransition(0, 0); // <- ini yang bikin langsung
        });

        tabProfile.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardPembeli2.this, ProfilePembeli.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        homeFloating.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardPembeli2.this, DashboardPembeli2.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });
    }

    private void setupBackPressHandler() {
        getOnBackPressedDispatcher().addCallback(this,
                new androidx.activity.OnBackPressedCallback(true) {
                    @Override public void handleOnBackPressed() {
                        moveTaskToBack(true);
                    }
                });
    }

    private void safeStartActivity(Intent intent) {
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal membuka halaman: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
