package com.example.digimartpembeli;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.HashMap;
import java.util.Map;

public class Cara_Pengajuan_Slot extends AppCompatActivity {

    private ImageView btnBack, imgAvatarToko;
    private TextView txtNamaToko, txtStatusToko;

    private ScrollView scrollView;
    private LinearLayout chatContainer;

    private EditText edtMessage;
    private ImageButton btnSend;

    private DatabaseReference roomRef;
    private ValueEventListener chatListener;

    private String pembeliId;
    private final String adminId = "ADMIN_001"; // ID admin bebas
    private String nomorSlot = ""; // dari Intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cara_pengajuan_slot);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            pembeliId = user.getUid();
        } else {
            finish();
            return;
        }

        nomorSlot = getIntent().getStringExtra("SLOT_NOMOR");
        if (nomorSlot == null) nomorSlot = "";

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        // Header
        btnBack = findViewById(R.id.btnBack);
        imgAvatarToko = findViewById(R.id.imgAvatarToko);
        txtNamaToko = findViewById(R.id.txtNamaToko);
        txtStatusToko = findViewById(R.id.txtStatusToko);
        scrollView = findViewById(R.id.scrollChat);
        chatContainer = findViewById(R.id.chatContainer);

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(0, 0);
        });
        txtNamaToko.setText("Admin");
        updateStatusAdmin();

        attachInputBar();

        // Firebase
        String roomId = adminId + "_" + pembeliId + "_SLOT_" + nomorSlot;
        roomRef = FirebaseDatabase.getInstance().getReference("chat_admin").child(roomId);

        // Auto kirim pesan pembuka
        cekDanKirimPesanPertama();

        listenChatRealtime();
    }

    private void updateStatusAdmin() {
        String roomId = adminId + "_" + pembeliId + "_SLOT_" + nomorSlot;
        DatabaseReference chatRef = FirebaseDatabase.getInstance().getReference("chat_admin").child(roomId);

        // Ambil pesan terakhir dari admin
        chatRef.orderByChild("timestamp").limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long lastTimestamp = 0;

                for (DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    Long ts = ds.child("timestamp").getValue(Long.class);
                    if ("admin".equals(sender) && ts != null) {
                        lastTimestamp = ts;
                    }
                }

                if (lastTimestamp > 0) {
                    long diffMillis = System.currentTimeMillis() - lastTimestamp;
                    long diffMinutes = diffMillis / (1000 * 60);
                    String statusText;

                    if (diffMinutes < 2) {
                        statusText = "online";
                    } else if (diffMinutes < 60) {
                        statusText = diffMinutes + " menit yang lalu";
                    } else {
                        long diffHours = diffMinutes / 60;
                        statusText = diffHours + " jam yang lalu";
                    }

                    txtStatusToko.setText(statusText);
                } else {
                    txtStatusToko.setText("offline");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    private void cekDanKirimPesanPertama() {
        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                // Jika BELUM ADA CHAT, kirim pesan pembuka
                if (!snapshot.exists()) {
                    kirimChat("pembeli", "Halo Admin, saya ingin mengajukan Slot " + nomorSlot);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    }

    private void attachInputBar() {
        LinearLayout root = findViewById(R.id.rootChatLayout);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(16, 12, 16, 12);
        bar.setBackgroundColor(Color.parseColor("#FFF8F0"));

        edtMessage = new EditText(this);
        edtMessage.setHint("Tulis pesan...");
        edtMessage.setMinLines(1);
        edtMessage.setMaxLines(4);
        edtMessage.setBackground(null);
        edtMessage.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        edtMessage.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        btnSend = new ImageButton(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setPadding(20,20,20,20);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(999f);
        bg.setColor(Color.parseColor("#FE5D26"));
        btnSend.setBackground(bg);

        // ⬇️ Tambahkan ini agar tombol bisa mengirim pesan
        btnSend.setOnClickListener(v -> {
            String pesan = edtMessage.getText().toString().trim();
            if (!pesan.isEmpty()) {
                kirimChat("pembeli", pesan);
                edtMessage.setText("");
            }
        });

        bar.addView(edtMessage);
        bar.addView(btnSend);

        root.addView(bar);
    }

    private void listenChatRealtime() {
        Query q = roomRef.orderByChild("timestamp");

        chatListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                chatContainer.removeAllViews();

                for(DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    String message = ds.child("message").getValue(String.class);

                    if(sender == null) sender = "";
                    if(message == null) message = "";

                    if("pembeli".equals(sender)) addBubbleRight(message);
                    else addBubbleLeft(message);
                }

                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));

                // ✅ Tandai semua pesan dari admin sebagai read
                markRoomAsRead();
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        };

        q.addValueEventListener(chatListener);
    }

    private void markRoomAsRead() {
        if(roomRef == null) return;

        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()) {
                    String sender = ds.child("sender").getValue(String.class);
                    Boolean readByPembeli = ds.child("readByPembeli").getValue(Boolean.class);
                    if(!"pembeli".equals(sender) && (readByPembeli == null || !readByPembeli)) {
                        ds.getRef().child("readByPembeli").setValue(true);
                    }
                }
            }

            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void kirimChat(String sender, String msg) {
        String id = roomRef.push().getKey();
        if (id == null) return;

        Map<String, Object> data = new HashMap<>();
        data.put("sender", sender);
        data.put("message", msg);
        data.put("timestamp", ServerValue.TIMESTAMP); // <- pakai server timestamp

        roomRef.child(id).setValue(data);
    }


    private void addBubbleRight(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(Color.BLACK);
        tv.setPadding(22,16,22,16);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#FFCCBC"));
        bg.setCornerRadius(24f);
        tv.setBackground(bg);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.END;
        lp.setMargins(70,12,0,12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    private void addBubbleLeft(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13);
        tv.setTextColor(Color.BLACK);
        tv.setPadding(22,16,22,16);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(24f);
        tv.setBackground(bg);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        lp.setMargins(0,12,70,12);
        tv.setLayoutParams(lp);

        chatContainer.addView(tv);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (roomRef != null && chatListener != null)
            roomRef.removeEventListener(chatListener);
    }
}
