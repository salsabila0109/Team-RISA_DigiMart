package com.example.digimartpembeli;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.view.View;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GantiPasswordPembeli extends AppCompatActivity {

    private ImageView btnBack;
    private TextView txtNamaPembeli, txtBioPembeli;
    private EditText inputPasswordLama, inputPasswordBaru, inputKonfirmasiPassword;
    private LinearLayout btnSimpan;

    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ganti_password_pembeli);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        // Inisialisasi view
        btnBack = findViewById(R.id.btnBack);
        txtNamaPembeli = findViewById(R.id.txtNamaPembeli);

        // Tambahkan TextView untuk bio
        txtBioPembeli = findViewById(R.id.txtBioPembeli);
        inputPasswordLama = findViewById(R.id.inputPasswordLama);
        inputPasswordBaru = findViewById(R.id.inputPasswordBaru);
        inputKonfirmasiPassword = findViewById(R.id.inputKonfirmasiPassword);
        btnSimpan = findViewById(R.id.btnSimpan);

        // ================= FOOTER NAVIGATION =================
        LinearLayout tabLikes = findViewById(R.id.tabLikes);
        LinearLayout tabHome = findViewById(R.id.tabHome);
        FrameLayout profileFloating = findViewById(R.id.profileFloating);

        // Klik Likes → pindah ke DaftarTokoSuka
        tabLikes.setOnClickListener(v -> {
            startActivity(new Intent(GantiPasswordPembeli.this, DaftarTokoSuka.class));
            overridePendingTransition(0, 0);
        });

        // Klik Home → pindah ke DashboardPembeli2
        tabHome.setOnClickListener(v -> {
            startActivity(new Intent(GantiPasswordPembeli.this, DashboardPembeli2.class));
            overridePendingTransition(0, 0);
        });

        // Klik Profile tetap di halaman ini (bisa diaktifkan popup jika ingin)
        profileFloating.setOnClickListener(v -> {
            startActivity(new Intent(GantiPasswordPembeli.this, ProfilePembeli.class));
            overridePendingTransition(0, 0); // transisi 0
            finish();
        });

        // Tombol back
        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(0, 0);
        });

        // Tombol simpan
        btnSimpan.setOnClickListener(v -> simpanPasswordBaru());

        // Ambil data profil dari Realtime Database
        if (currentUser != null) {
            String uid = currentUser.getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference("Users/Pembeli").child(uid);

            mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String nama = snapshot.child("nama").getValue(String.class);
                        String bio = snapshot.child("bio").getValue(String.class);

                        if (nama != null) txtNamaPembeli.setText(nama);
                        if (bio != null) txtBioPembeli.setText(bio);
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Toast.makeText(GantiPasswordPembeli.this, "Gagal mengambil profil", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void simpanPasswordBaru() {
        String passLama = inputPasswordLama.getText().toString().trim();
        String passBaru = inputPasswordBaru.getText().toString().trim();
        String passKonfirmasi = inputKonfirmasiPassword.getText().toString().trim();

        // Validasi input
        if (TextUtils.isEmpty(passLama)) {
            inputPasswordLama.setError("Password lama wajib diisi");
            inputPasswordLama.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(passBaru)) {
            inputPasswordBaru.setError("Password baru wajib diisi");
            inputPasswordBaru.requestFocus();
            return;
        }

        if (passBaru.length() < 6) {
            inputPasswordBaru.setError("Password baru minimal 6 karakter");
            inputPasswordBaru.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(passKonfirmasi)) {
            inputKonfirmasiPassword.setError("Konfirmasi password wajib diisi");
            inputKonfirmasiPassword.requestFocus();
            return;
        }

        if (!passBaru.equals(passKonfirmasi)) {
            inputKonfirmasiPassword.setError("Konfirmasi password tidak cocok");
            inputKonfirmasiPassword.requestFocus();
            return;
        }

        if (currentUser == null) {
            Toast.makeText(this, "User tidak ditemukan", Toast.LENGTH_SHORT).show();
            return;
        }

        // Re-authenticate user
        AuthCredential credential = EmailAuthProvider.getCredential(currentUser.getEmail(), passLama);
        currentUser.reauthenticate(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Update password baru
                currentUser.updatePassword(passBaru).addOnCompleteListener(updateTask -> {
                    if (updateTask.isSuccessful()) {
                        Toast.makeText(GantiPasswordPembeli.this, "Password berhasil diubah", Toast.LENGTH_SHORT).show();
                        finish(); // kembali ke ProfilePembeli
                    } else {
                        Toast.makeText(GantiPasswordPembeli.this, "Gagal mengubah password: " +
                                updateTask.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Toast.makeText(GantiPasswordPembeli.this, "Password lama salah", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
