package com.example.digimartpembeli;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Detail_Toko extends AppCompatActivity {

    private ImageView btnBackDetailToko, imgAvatarToko, btnLikeToko;
    private TextView tvNamaTokoHeader, tvStatusToko, tvNamaToko,
            tvNamaPemilik, tvNoTelepon, tvKategori, tvDeskripsiToko;
    private Button btnChatToko;

    private boolean isLiked = false;
    private String uidPembeli;
    private String tokoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_toko);

        // === FIND VIEW ===
        btnBackDetailToko = findViewById(R.id.btnBackDetailToko);
        imgAvatarToko = findViewById(R.id.imgAvatarToko);
        imgAvatarToko.setClipToOutline(true);
        tvNamaTokoHeader = findViewById(R.id.tvNamaTokoHeader);
        tvStatusToko = findViewById(R.id.tvStatusToko);
        tvNamaToko = findViewById(R.id.tvNamaToko);
        tvNamaPemilik = findViewById(R.id.tvNamaPemilik);
        tvNoTelepon = findViewById(R.id.tvNoTelepon);
        tvKategori = findViewById(R.id.tvKategori);
        tvDeskripsiToko = findViewById(R.id.tvDeskripsiToko);
        btnChatToko = findViewById(R.id.btnChatToko);
        btnLikeToko = findViewById(R.id.btnLikeToko);

        // SEMBUNYIKAN CHAT JIKA BELUM LOGIN
        FirebaseUser userLogin = FirebaseAuth.getInstance().getCurrentUser();

        if (userLogin == null) {
            btnChatToko.setVisibility(Button.GONE);
        } else {
            btnChatToko.setVisibility(Button.VISIBLE);
        }

        // === GET INTENT ===
        Intent intent = getIntent();
        tokoId = intent.getStringExtra("TOKO_ID"); // key Penjual
        String namaToko = intent.getStringExtra("NAMA_TOKO");
        String pemilik = intent.getStringExtra("PEMILIK");
        String kontak = intent.getStringExtra("KONTAK");
        String status = intent.getStringExtra("STATUS");
        String deskripsi = intent.getStringExtra("DESKRIPSI");
        String fotoTokoBase64 = intent.getStringExtra("FOTO");

        // Ambil kategori sebagai ArrayList dari Intent
        ArrayList<String> kategoriList = intent.getStringArrayListExtra("KATEGORI");
        String kategori = (kategoriList != null) ? String.join(", ", kategoriList) : "-";

        // === SET FOTO TOKO ===
        try {
            if (fotoTokoBase64 != null && !fotoTokoBase64.trim().isEmpty() && fotoTokoBase64.length() > 20) {
                byte[] decode = Base64.decode(fotoTokoBase64, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decode, 0, decode.length);
                imgAvatarToko.setImageBitmap(bmp);
            } else {
                // FOTO KOSONG → jangan pakai drawable profile, biarkan hanya circle_mask
                imgAvatarToko.setImageBitmap(null);
            }
        } catch (Exception e) {
            imgAvatarToko.setImageBitmap(null); // fallback → hanya circle_mask
        }

        // === SET DATA KE TEXTVIEW ===
        tvNamaTokoHeader.setText(namaToko);
        tvNamaToko.setText(namaToko);
        tvNamaPemilik.setText(pemilik);
        tvNoTelepon.setText(kontak);
        tvKategori.setText(kategori);
        tvDeskripsiToko.setText(deskripsi);

        tvStatusToko.setText(status); // tampilkan status apapun
        tvStatusToko.setVisibility(TextView.VISIBLE); // pastikan selalu terlihat

        // beri warna berbeda sesuai status
        if (status != null && status.equalsIgnoreCase("Buka")) {
            tvStatusToko.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else if (status != null && status.equalsIgnoreCase("Tutup")) {
            tvStatusToko.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        } else {
            tvStatusToko.setTextColor(getResources().getColor(android.R.color.darker_gray));
        }

        // === TOMBOL BACK ===
        btnBackDetailToko.setOnClickListener(v -> {
            onBackPressed();
            overridePendingTransition(0, 0); // 🔥 Transisi 0
        });

        // === TOMBOL CHAT ===
        btnChatToko.setOnClickListener(v -> {

            FirebaseUser userNow = FirebaseAuth.getInstance().getCurrentUser();

            if (userNow == null) {
                Toast.makeText(Detail_Toko.this,
                        "Silakan login untuk melakukan chat toko",
                        Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Detail_Toko.this, LoginPembeli.class);
                startActivity(loginIntent);
                overridePendingTransition(0, 0); // 🔥 Transisi 0 ke login
                return;
            }

            Intent chatIntent = new Intent(Detail_Toko.this, Chat_toko_pembeli.class);
            chatIntent.putExtra("TOKO_ID", tokoId);
            chatIntent.putExtra("NAMA_TOKO", namaToko);
            startActivity(chatIntent);
            overridePendingTransition(0, 0); // 🔥 Transisi 0 ke chat
        });

        // =======================================================
        //                      LIKE TOKO
        // =======================================================
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            btnLikeToko.setVisibility(ImageView.GONE);
            return;
        }

        uidPembeli = user.getUid();
        btnLikeToko.setVisibility(ImageView.VISIBLE);

        DatabaseReference sukaRef = FirebaseDatabase.getInstance()
                .getReference("toko_suka")
                .child(uidPembeli); // child = uid pembeli

        // Cek apakah pembeli sudah like toko ini
        sukaRef.child(tokoId).get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                isLiked = true;
                btnLikeToko.setImageResource(R.drawable.likes_ic);
            } else {
                isLiked = false;
                btnLikeToko.setImageResource(R.drawable.sukai);
            }
        });

        // Klik Like / Unlike
        btnLikeToko.setOnClickListener(v -> {

            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

            if (currentUser == null) {
                Toast.makeText(Detail_Toko.this,
                        "Silakan login untuk menyukai toko",
                        Toast.LENGTH_SHORT).show();

                startActivity(new Intent(Detail_Toko.this, LoginPembeli.class));
                return;
            }

            if (!isLiked) {
                sukaRef.child(tokoId).setValue(true)
                        .addOnSuccessListener(a -> {
                            isLiked = true;
                            btnLikeToko.setImageResource(R.drawable.likes_ic);
                            Toast.makeText(Detail_Toko.this, "Toko disukai", Toast.LENGTH_SHORT).show();
                        });

            } else {
                sukaRef.child(tokoId).removeValue()
                        .addOnSuccessListener(a -> {
                            isLiked = false;
                            btnLikeToko.setImageResource(R.drawable.sukai);
                            Toast.makeText(Detail_Toko.this, "Toko tidak disukai", Toast.LENGTH_SHORT).show();
                        });
            }
        });
    }
}
