package com.example.digimartpembeli;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class TokoAdapterSuka extends RecyclerView.Adapter<TokoAdapterSuka.ViewHolder> {

    public interface OnTokoClickListener {
        void onClick(Toko toko);
    }

    private List<Toko> tokoList;
    private OnTokoClickListener listener;
    private DatabaseReference tokoSukaRef;

    public TokoAdapterSuka(List<Toko> tokoList, DatabaseReference tokoSukaRef, OnTokoClickListener listener) {
        this.tokoList = tokoList;
        this.tokoSukaRef = tokoSukaRef;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_toko_suka, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Toko t = tokoList.get(position);

        h.namaToko.setText(t.getNamaToko());
        h.pemilikToko.setText("Pemilik: " + t.getPemilik());
        h.kontakToko.setText("Kontak: " + t.getKontak());
        h.deskripsiToko.setText(t.getDeskripsi());

        // STATUS TOKO
        if ("BUKA".equalsIgnoreCase(t.getStatus())) {
            h.badgeStatus.setText("BUKA");
            h.badgeStatus.setTextColor(0xFF2E7D32);
        } else {
            h.badgeStatus.setText("TUTUP");
            h.badgeStatus.setTextColor(0xFFC62828);
        }

        // FOTO TOKO
        try {
            String foto = t.getFotoTokoBase64();
            if (foto != null && !foto.trim().isEmpty() && foto.length() > 20) {
                byte[] decode = Base64.decode(foto, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decode, 0, decode.length);
                h.fotoToko.setImageBitmap(bmp);
            } else {
                // FOTO KOSONG → jangan pakai drawable, cukup circle_mask
                h.fotoToko.setImageBitmap(null);
            }
        } catch (Exception e) {
            h.fotoToko.setImageBitmap(null); // fallback → biarkan circle_mask
        }

        // LIKE ICON (selalu liked)
        h.likeIcon.setImageResource(R.drawable.likes_ic);

        // ============================
        // TOMBOL DETAIL TOKO
        // ============================
        h.btnDetail.setOnClickListener(v -> {
            if (listener != null) listener.onClick(t);
        });

        // ============================
        // TOMBOL HAPUS DARI SUKA
        // ============================
        h.btnHapus.setOnClickListener(v -> {

            new AlertDialog.Builder(v.getContext())
                    .setTitle("Konfirmasi")
                    .setMessage("Yakin ingin menghapus toko yang disukai?")
                    .setPositiveButton("Ya", (dialog, which) -> {

                        dialog.dismiss();

                        if (t.getId() != null) {

                            // 1. Hapus dari Firebase
                            tokoSukaRef.child(t.getId()).removeValue()
                                    .addOnSuccessListener(a -> {

                                        // 2. Ambil posisi item
                                        int pos = h.getAdapterPosition();
                                        if (pos == RecyclerView.NO_POSITION) return;

                                        // 3. Hapus dari list RecyclerView
                                        tokoList.remove(pos);
                                        notifyItemRemoved(pos);

                                        Toast.makeText(v.getContext(),
                                                "Toko dihapus dari daftar suka",
                                                Toast.LENGTH_SHORT).show();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(v.getContext(),
                                                "Gagal menghapus: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show();
                                    });
                        }

                    })
                    .setNegativeButton("Tidak", (dialog, which) -> dialog.dismiss())
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return tokoList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView fotoToko, likeIcon;
        TextView namaToko, pemilikToko, kontakToko, deskripsiToko, badgeStatus;
        LinearLayout btnHapus;
        TextView btnDetail;

        public ViewHolder(@NonNull View v) {
            super(v);
            fotoToko = v.findViewById(R.id.fotoToko);
            likeIcon = v.findViewById(R.id.likeIcon);
            namaToko = v.findViewById(R.id.namaToko);
            pemilikToko = v.findViewById(R.id.pemilikToko);
            kontakToko = v.findViewById(R.id.kontakToko);
            deskripsiToko = v.findViewById(R.id.deskripsiToko);
            badgeStatus = v.findViewById(R.id.badgeStatus);
            btnHapus = v.findViewById(R.id.btnHapus);
            btnDetail = v.findViewById(R.id.btnDetail);
        }
    }

    public void updateList(List<Toko> newList) {
        tokoList = newList;
        notifyDataSetChanged();
    }
}
