package com.example.digimartpembeli;

public class Slot {
    private String idSlot;
    private String kategori;
    private String namaToko;
    private String pemilik;
    private String phone;
    private String status;

    public Slot() {} // Required empty constructor

    public String getIdSlot() { return idSlot; }
    public void setIdSlot(String idSlot) { this.idSlot = idSlot; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getNamaToko() { return namaToko; }
    public void setNamaToko(String namaToko) { this.namaToko = namaToko; }

    public String getPemilik() { return pemilik; }
    public void setPemilik(String pemilik) { this.pemilik = pemilik; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
