package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditProfilePembeli extends AppCompatActivity {

    private ImageView btnBack;
    private EditText inputNamaPembeli, inputEmailPembeli, inputBioPembeli, inputPasswordLama;
    private TextView labelPasswordLama;
    private LinearLayout btnSimpan;
    private LinearLayout tabHome, tabLikes, tabProfile; // footer
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile_pembeli);

        mAuth = FirebaseAuth.getInstance();

        btnBack = findViewById(R.id.btnBack);
        inputNamaPembeli = findViewById(R.id.inputNamaPembeli);
        inputEmailPembeli = findViewById(R.id.inputEmailPembeli);
        inputBioPembeli = findViewById(R.id.inputBioPembeli);
        inputPasswordLama = findViewById(R.id.inputPasswordLama);
        labelPasswordLama = findViewById(R.id.labelPasswordLama);
        btnSimpan = findViewById(R.id.btnSimpan);
        tabHome = findViewById(R.id.tabHome);
        tabLikes = findViewById(R.id.tabLikes);
        tabProfile = findViewById(R.id.tabProfile);

        loadUserData();

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(0, 0);
        });

        btnSimpan.setOnClickListener(v -> simpanProfil());

        // Tampilkan password lama jika email diubah
        inputEmailPembeli.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser == null) return;

                String emailAuth = currentUser.getEmail();
                if (!s.toString().equals(emailAuth)) {
                    inputPasswordLama.setVisibility(View.VISIBLE);
                    labelPasswordLama.setVisibility(View.VISIBLE);
                } else {
                    inputPasswordLama.setText("");
                    inputPasswordLama.setVisibility(View.GONE);
                    labelPasswordLama.setVisibility(View.GONE);
                }
            }
        });
        initFooterNav(); // footer navigation
    }

    private void loadUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        mDatabase = FirebaseDatabase.getInstance()
                .getReference("Users/Pembeli")
                .child(currentUser.getUid());

        mDatabase.get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                String nama = snapshot.child("nama").getValue(String.class);
                String bio = snapshot.child("bio").getValue(String.class);
                String emailAuth = currentUser.getEmail();

                if (nama != null) inputNamaPembeli.setText(nama);
                if (bio != null) inputBioPembeli.setText(bio);
                if (emailAuth != null) inputEmailPembeli.setText(emailAuth);
            }
        }).addOnFailureListener(e ->
                Toast.makeText(EditProfilePembeli.this, "Gagal load data", Toast.LENGTH_SHORT).show()
        );
    }

    private void simpanProfil() {
        String nama = inputNamaPembeli.getText().toString().trim();
        String emailBaru = inputEmailPembeli.getText().toString().trim();
        String bio = inputBioPembeli.getText().toString().trim();
        String passwordLama = inputPasswordLama.getText().toString().trim();

        if (TextUtils.isEmpty(nama)) {
            inputNamaPembeli.setError("Nama wajib diisi");
            inputNamaPembeli.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(emailBaru)) {
            inputEmailPembeli.setError("Email wajib diisi");
            inputEmailPembeli.requestFocus();
            return;
        }

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        String emailAuth = currentUser.getEmail();

        if (emailBaru.equals(emailAuth)) {
            updateDatabaseOnly(nama, emailBaru, bio);
        } else {
            if (TextUtils.isEmpty(passwordLama)) {
                inputPasswordLama.setError("Masukkan password lama untuk ganti email");
                inputPasswordLama.requestFocus();
                return;
            }

            AuthCredential credential = EmailAuthProvider.getCredential(emailAuth, passwordLama);
            currentUser.reauthenticate(credential).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    currentUser.updateEmail(emailBaru).addOnCompleteListener(emailTask -> {
                        if (emailTask.isSuccessful()) {
                            updateDatabaseOnly(nama, emailBaru, bio);
                            inputPasswordLama.setText("");
                            inputPasswordLama.setVisibility(View.GONE);
                            labelPasswordLama.setVisibility(View.GONE);
                            Toast.makeText(EditProfilePembeli.this,
                                    "Email berhasil diubah", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(EditProfilePembeli.this,
                                    "Gagal update email: " + emailTask.getException().getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    Toast.makeText(EditProfilePembeli.this,
                            "Re-authentication gagal: " + task.getException().getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void updateDatabaseOnly(String nama, String email, String bio) {
        if (mDatabase == null) return;

        mDatabase.child("nama").setValue(nama);
        mDatabase.child("email").setValue(email);
        mDatabase.child("bio").setValue(bio)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(EditProfilePembeli.this,
                            "Profil berhasil diperbarui", Toast.LENGTH_SHORT).show();

                    // Kirim data balik ke ProfilePembeli
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("nama", nama);
                    resultIntent.putExtra("email", email);
                    resultIntent.putExtra("bio", bio);
                    setResult(RESULT_OK, resultIntent);

                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(EditProfilePembeli.this,
                                "Gagal memperbarui profil", Toast.LENGTH_SHORT).show()
                );
    }
    private void initFooterNav() {

        tabHome.setOnClickListener(v -> {
            startActivity(new Intent(EditProfilePembeli.this, DashboardPembeli2.class));
            overridePendingTransition(0, 0); // tanpa animasi
        });

        tabLikes.setOnClickListener(v -> {
            startActivity(new Intent(EditProfilePembeli.this, DaftarTokoSuka.class));
            overridePendingTransition(0, 0); // tanpa animasi
        });

        tabProfile.setOnClickListener(v -> {
            startActivity(new Intent(EditProfilePembeli.this, ProfilePembeli.class));
            overridePendingTransition(0, 0); // transisi 0
            finish();
        });
    }
}
