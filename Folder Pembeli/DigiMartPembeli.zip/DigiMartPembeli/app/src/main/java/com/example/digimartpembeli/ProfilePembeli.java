package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProfilePembeli extends AppCompatActivity {

    private LinearLayout tabHome, tabLikes, tabProfile;
    private LinearLayout menuLogout;
    private LinearLayout btnEditProfile, menuTokoSuka, menuChatAdmin, menuGantiPassword, btnLihatSlot;
    private LinearLayout menuHapusAkun;
    private TextView tvUserName, tvBio;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_pembeli);

        mAuth = FirebaseAuth.getInstance();
        tvUserName = findViewById(R.id.userName);
        tvBio = findViewById(R.id.tvBio);

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String uid = currentUser.getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference("Users/Pembeli").child(uid);

            // Ambil data awal
            mDatabase.get().addOnSuccessListener(snapshot -> {
                if (snapshot.exists()) {
                    String nama = snapshot.child("nama").getValue(String.class);
                    String bio = snapshot.child("bio").getValue(String.class);

                    if (nama != null) tvUserName.setText(nama);
                    if (bio != null) tvBio.setText(bio);
                }
            });
        }

        initFooterNav();
        initMenuActions();
        initHeaderActions();
    }

    private void initMenuActions() {

        btnEditProfile = findViewById(R.id.btnEditProfile);

        LinearLayout menuContainer = findViewById(R.id.menuContainer);
        menuTokoSuka = (LinearLayout) menuContainer.getChildAt(0);
        menuChatAdmin = (LinearLayout) menuContainer.getChildAt(1);
        menuGantiPassword = (LinearLayout) menuContainer.getChildAt(2);
        menuLogout = (LinearLayout) menuContainer.getChildAt(3);
        menuHapusAkun = (LinearLayout) menuContainer.getChildAt(4); // sesuai urutan di XML
        menuHapusAkun.setOnClickListener(v -> showHapusAkunDialog());

        btnLihatSlot = findViewById(R.id.btnLihatSlot);

        // Edit Profile
        btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(ProfilePembeli.this, EditProfilePembeli.class);
            startActivityForResult(intent, 101);
            overridePendingTransition(0, 0); // Tidak bergeser
        });

        // Toko Suka
        menuTokoSuka.setOnClickListener(v -> {
            startActivity(new Intent(ProfilePembeli.this, DaftarTokoSuka.class));
            overridePendingTransition(0, 0); // Tidak bergeser
        });

        // Chat Admin
        menuChatAdmin.setOnClickListener(v -> {
            startActivity(new Intent(ProfilePembeli.this, Chat_Bantuan.class));
            overridePendingTransition(0, 0); // Tidak bergeser
        });

        // Ganti Password
        menuGantiPassword.setOnClickListener(v -> {
            startActivity(new Intent(ProfilePembeli.this, GantiPasswordPembeli.class));
            overridePendingTransition(0, 0); // Tidak bergeser
        });

        // Lihat Slot
        btnLihatSlot.setOnClickListener(v -> {
            startActivity(new Intent(ProfilePembeli.this, Profile_Lihat_Slot.class));
            overridePendingTransition(0, 0); // Tidak bergeser
        });

        // Logout
        menuLogout.setOnClickListener(v -> showLogoutDialog());
    }

    private void showHapusAkunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Akun")
                .setMessage("Yakin ingin menghapus akun?")
                .setPositiveButton("Ya", (dialog, which) -> hapusAkun())
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void hapusAkun() {
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null) {
            String uid = user.getUid();

            // Hapus data di Realtime Database
            mDatabase.removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    // Hapus akun di Firebase Auth
                    user.delete().addOnCompleteListener(authTask -> {
                        if (authTask.isSuccessful()) {
                            Toast.makeText(ProfilePembeli.this, "Akun berhasil dihapus", Toast.LENGTH_SHORT).show();

                            // Hapus shared preferences / token login
                            SharedPreferences preferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
                            preferences.edit().clear().apply();

                            // Kembali ke halaman login / dashboard awal
                            Intent intent = new Intent(ProfilePembeli.this, LoginPembeli.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(ProfilePembeli.this, "Gagal menghapus akun: " + authTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    Toast.makeText(ProfilePembeli.this, "Gagal menghapus data: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    // Fungsi tampilkan dialog logout
    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Apakah Anda yakin ingin logout?")
                .setPositiveButton("Ya", (dialog, which) -> performLogout())
                .setNegativeButton("Tidak", null)
                .show();
    }

    // Fungsi logout
    private void performLogout() {
        // Logout Firebase
        mAuth.signOut();

        // Hapus shared preferences / token login jika ada
        SharedPreferences preferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear(); // hapus semua
        editor.apply();

        // Kembali ke DashboardPembeli untuk login
        Intent intent = new Intent(ProfilePembeli.this, DashboardPembeli.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // clear back stack
        startActivity(intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            String nama = data.getStringExtra("nama");
            String bio = data.getStringExtra("bio");

            if (nama != null) tvUserName.setText(nama);
            if (bio != null) tvBio.setText(bio);
        }
    }

    // Footer dan header bisa tetap seperti sebelumnya
    private void initFooterNav() {
        tabLikes = findViewById(R.id.tabLikes);
        tabHome = findViewById(R.id.tabHome);
        tabProfile = findViewById(R.id.tabProfile);

        // Likes
        if (tabLikes != null) {
            tabLikes.setOnClickListener(v -> {
                startActivity(new Intent(ProfilePembeli.this, DaftarTokoSuka.class));
                overridePendingTransition(0, 0); // hilangkan animasi
            });
        }

        // Home
        if (tabHome != null) {
            tabHome.setOnClickListener(v -> {
                startActivity(new Intent(ProfilePembeli.this, DashboardPembeli2.class));
                overridePendingTransition(0, 0); // hilangkan animasi
            });
        }

        // Profile tetap di sini (tidak melakukan apa-apa)
        if (tabProfile != null) {
            tabProfile.setOnClickListener(v -> {});
        }
    }

    private void initHeaderActions() {
        ImageView btnChatHeader = findViewById(R.id.btnChatHeader);

        if (btnChatHeader != null) {
            btnChatHeader.setOnClickListener(v -> {
                startActivity(new Intent(ProfilePembeli.this, Chat.class));
                overridePendingTransition(0, 0);
            });
        }
    }
}
