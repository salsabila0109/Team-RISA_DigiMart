package com.example.digimartpembeli;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DaftarPembeli extends AppCompatActivity {

    private EditText etNama, etEmail, etPassword, etConfirmPassword;
    private Button btnDaftarPembeli;
    private TextView tvMasuk;

    private FirebaseAuth auth;
    private DatabaseReference dbPembeli;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_pembeli);

        auth = FirebaseAuth.getInstance();
        dbPembeli = FirebaseDatabase.getInstance().getReference("Users").child("Pembeli");

        etNama = findViewById(R.id.etNama);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnDaftarPembeli = findViewById(R.id.btnDaftarPembeli);
        tvMasuk = findViewById(R.id.tvMasuk);

        btnDaftarPembeli.setOnClickListener(v -> daftarPembeli());
        tvMasuk.setOnClickListener(v -> pindahLogin());
    }

    private void daftarPembeli() {
        String nama = etNama.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirm = etConfirmPassword.getText().toString().trim();

        // Validasi
        if (TextUtils.isEmpty(nama)) {
            etNama.setError("Nama wajib diisi");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email wajib diisi");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password wajib diisi");
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("Password minimal 6 karakter");
            return;
        }
        if (!password.equals(confirm)) {
            etConfirmPassword.setError("Konfirmasi password tidak cocok");
            return;
        }

        // Buat akun Firebase Auth
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {

                        FirebaseUser user = auth.getCurrentUser();
                        if (user == null) return;

                        String uid = user.getUid();

                        // Data pembeli
                        HashMap<String, Object> data = new HashMap<>();
                        data.put("nama", nama);
                        data.put("email", email);
                        data.put("uid", uid);

                        // Simpan ke Realtime Database
                        dbPembeli.child(uid).setValue(data)
                                .addOnCompleteListener(saveTask -> {
                                    if (saveTask.isSuccessful()) {
                                        Toast.makeText(this,
                                                "Pendaftaran berhasil!",
                                                Toast.LENGTH_SHORT).show();

                                        // Pindah ke Dashboard
                                        startActivity(new Intent(this, DashboardPembeli2.class));
                                        finish();
                                    } else {
                                        Toast.makeText(this,
                                                "Gagal menyimpan data!",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                });

                    } else {
                        Toast.makeText(this,
                                "Gagal daftar: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void pindahLogin() {
        startActivity(new Intent(this, LoginPembeli.class));
        finish();
    }
}
