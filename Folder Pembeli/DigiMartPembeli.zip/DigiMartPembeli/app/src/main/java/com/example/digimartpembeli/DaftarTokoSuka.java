package com.example.digimartpembeli;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DaftarTokoSuka extends AppCompatActivity {

    private EditText searchBar;
    private RecyclerView containerToko;
    private TokoAdapterSuka adapter;
    private DatabaseReference tokoSukaRef, penjualRef;
    private String userId;

    // Bottom nav
    private LinearLayout tabHome, tabProfile;
    private FrameLayout tabLikesFloating;

    // Tab kategori
    private LinearLayout tabSemua, tabMakanan, tabPakaian, tabAlat, tabMainan, tabLainnya;
    private TextView textSemua, textMakanan, textPakaian, textAlat, textMainan, textLainnya;
    private View lineSemua, lineMakanan, linePakaian, lineAlat, lineMainan, lineLainnya;
    private String kategoriAktif = "Semua";

    // List toko
    private List<Toko> tokoList = new ArrayList<>();
    private List<Toko> filteredList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_toko_suka);

        initViews();
        setupBottomNav();
        setupTabKategori();
        setupSearchBar();

        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        tokoSukaRef = FirebaseDatabase.getInstance()
                .getReference("toko_suka")
                .child(userId);

        penjualRef = FirebaseDatabase.getInstance().getReference("Penjual");

        // 🔥 Pindahkan adapter ke sini!
        adapter = new TokoAdapterSuka(tokoList, tokoSukaRef, toko -> {
            Intent intent = new Intent(DaftarTokoSuka.this, Detail_Toko.class);
            intent.putExtra("TOKO_ID", toko.getId());
            intent.putExtra("NAMA_TOKO", toko.getNamaToko());
            intent.putExtra("PEMILIK", toko.getPemilik());
            intent.putExtra("KONTAK", toko.getKontak());
            intent.putExtra("DESKRIPSI", toko.getDeskripsi());
            if (toko.getKategori() != null) {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>(toko.getKategori()));
            } else {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>());
            }
            intent.putExtra("STATUS", toko.getStatus());
            intent.putExtra("FOTO", toko.getFotoTokoBase64());
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        containerToko.setAdapter(adapter);

        loadTokoSuka();
    }


    private void initViews() {
        searchBar = findViewById(R.id.searchBar);

        containerToko = findViewById(R.id.containerToko);
        containerToko.setLayoutManager(new LinearLayoutManager(this));

        // Bottom nav
        tabHome = findViewById(R.id.tabHome);
        tabProfile = findViewById(R.id.tabProfile);
        tabLikesFloating = findViewById(R.id.likesFloating);

        ImageView btnChat = findViewById(R.id.btnChat);
        btnChat.setOnClickListener(v -> {
            startActivity(new Intent(DaftarTokoSuka.this, Chat.class));
            overridePendingTransition(0, 0);
        });

        // Tab kategori
        tabSemua = findViewById(R.id.tabSemua);
        tabMakanan = findViewById(R.id.tabMakanan);
        tabPakaian = findViewById(R.id.tabPakaian);
        tabAlat = findViewById(R.id.tabAlat);
        tabMainan = findViewById(R.id.tabMainan);
        tabLainnya = findViewById(R.id.tabLainnya);

        textSemua = findViewById(R.id.textSemua);
        textMakanan = findViewById(R.id.textMakanan);
        textPakaian = findViewById(R.id.textPakaian);
        textAlat = findViewById(R.id.textAlat);
        textMainan = findViewById(R.id.textMainan);
        textLainnya = findViewById(R.id.textLainnya);

        lineSemua = findViewById(R.id.lineSemua);
        lineMakanan = findViewById(R.id.lineMakanan);
        linePakaian = findViewById(R.id.linePakaian);
        lineAlat = findViewById(R.id.lineAlat);
        lineMainan = findViewById(R.id.lineMainan);
        lineLainnya = findViewById(R.id.lineLainnya);
    }

    // ====================================================
    // Load semua toko suka dari Firebase
    // ====================================================
    private void loadTokoSuka() {
        tokoList.clear();
        filteredList.clear();

        tokoSukaRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                for (DataSnapshot tokoSnapshot : snapshot.getChildren()) {
                    String tokoId = tokoSnapshot.getKey();

                    penjualRef.child(tokoId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot tokoDetail) {
                            if (tokoDetail.exists()) {
                                Toko toko = tokoDetail.getValue(Toko.class);
                                if (toko != null) {
                                    toko.setId(tokoId);
                                    tokoList.add(toko);
                                }
                                applyFilters(); // update tampilan setiap ada tambahan
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(DaftarTokoSuka.this, "Gagal load toko: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // ====================================================
    // FILTER
    // ====================================================
    private void applyFilters() {
        String query = searchBar.getText().toString().toLowerCase();
        filteredList.clear();

        for (Toko t : tokoList) {
            boolean cocokKategori = kategoriAktif.equals("Semua") ||
                    (t.getKategori() != null && t.getKategori().stream()
                            .anyMatch(k -> k.equalsIgnoreCase(kategoriAktif)));

            boolean cocokSearch = t.getNamaToko() != null && t.getNamaToko().toLowerCase().contains(query);

            if (cocokKategori && cocokSearch) {
                filteredList.add(t);
            }
        }

        adapter.updateList(filteredList);
    }


    // ====================================================
    // Tambah card view
    // ====================================================
    private void addCardView(Toko t) {
        View card = getLayoutInflater().inflate(R.layout.card_toko_suka, null);

        ImageView fotoToko = card.findViewById(R.id.fotoToko);
        TextView namaToko = card.findViewById(R.id.namaToko);
        TextView badgeStatus = card.findViewById(R.id.badgeStatus);
        TextView pemilikToko = card.findViewById(R.id.pemilikToko);
        TextView kontakToko = card.findViewById(R.id.kontakToko);
        TextView deskripsiToko = card.findViewById(R.id.deskripsiToko);
        ImageView likeIcon = card.findViewById(R.id.likeIcon);
        LinearLayout btnHapus = card.findViewById(R.id.btnHapus);
        TextView btnDetail = card.findViewById(R.id.btnDetail);

        namaToko.setText(t.getNamaToko());
        pemilikToko.setText("Pemilik: " + t.getPemilik());
        kontakToko.setText("Kontak: " + t.getKontak());
        deskripsiToko.setText(t.getDeskripsi());
        String status = t.getStatus() != null ? t.getStatus() : "";
        badgeStatus.setTextColor("BUKA".equalsIgnoreCase(status) ? Color.parseColor("#2E7D32") : Color.RED);

        likeIcon.setImageResource(R.drawable.likes_ic);

        // decode foto Base64
        try {
            if (t.getFotoTokoBase64() != null && !t.getFotoTokoBase64().trim().isEmpty()) {
                byte[] decoded = Base64.decode(t.getFotoTokoBase64(), Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                fotoToko.setImageBitmap(bitmap);
            }
        } catch (Exception ignored) {}

        // Detail
        btnDetail.setOnClickListener(v -> {
            Intent intent = new Intent(DaftarTokoSuka.this, Detail_Toko.class);

            intent.putExtra("TOKO_ID", t.getId());
            intent.putExtra("NAMA_TOKO", t.getNamaToko());
            intent.putExtra("PEMILIK", t.getPemilik());
            intent.putExtra("KONTAK", t.getKontak());
            intent.putExtra("DESKRIPSI", t.getDeskripsi());

            // kategori List<String> → ArrayList<String>
            if (t.getKategori() != null) {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>(t.getKategori()));
            } else {
                intent.putStringArrayListExtra("KATEGORI", new ArrayList<>());
            }

            intent.putExtra("STATUS", t.getStatus());
            intent.putExtra("FOTO", t.getFotoTokoBase64());

            startActivity(intent);
            overridePendingTransition(0, 0);
        });
    }

    // ====================================================
    // SEARCH
    // ====================================================
    private void setupSearchBar() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilters();
            }
        });
    }

    // ====================================================
    // TAB KATEGORI
    // ====================================================
    private void setupTabKategori() {
        selectTab("Semua");

        tabSemua.setOnClickListener(v -> {
            kategoriAktif = "Semua";
            selectTab("Semua");
            applyFilters();
        });
        tabMakanan.setOnClickListener(v -> {
            kategoriAktif = "Makanan";
            selectTab("Makanan");
            applyFilters();
        });
        tabPakaian.setOnClickListener(v -> {
            kategoriAktif = "Pakaian";
            selectTab("Pakaian");
            applyFilters();
        });
        tabAlat.setOnClickListener(v -> {
            kategoriAktif = "Alat";
            selectTab("Alat");
            applyFilters();
        });
        tabMainan.setOnClickListener(v -> {
            kategoriAktif = "Mainan";
            selectTab("Mainan");
            applyFilters();
        });
        tabLainnya.setOnClickListener(v -> {
            kategoriAktif = "Lain";
            selectTab("Lainnya");
            applyFilters();
        });
    }

    private void selectTab(String kategori) {
        int defaultColor = 0xFF616161;
        int orange = 0xFFFF5722;

        textSemua.setTextColor(defaultColor);
        textMakanan.setTextColor(defaultColor);
        textPakaian.setTextColor(defaultColor);
        textAlat.setTextColor(defaultColor);
        textMainan.setTextColor(defaultColor);
        textLainnya.setTextColor(defaultColor);

        lineSemua.setBackgroundColor(0x00000000);
        lineMakanan.setBackgroundColor(0x00000000);
        linePakaian.setBackgroundColor(0x00000000);
        lineAlat.setBackgroundColor(0x00000000);
        lineMainan.setBackgroundColor(0x00000000);
        lineLainnya.setBackgroundColor(0x00000000);

        switch (kategori) {
            case "Semua": textSemua.setTextColor(orange); lineSemua.setBackgroundColor(orange); break;
            case "Makanan": textMakanan.setTextColor(orange); lineMakanan.setBackgroundColor(orange); break;
            case "Pakaian": textPakaian.setTextColor(orange); linePakaian.setBackgroundColor(orange); break;
            case "Alat": textAlat.setTextColor(orange); lineAlat.setBackgroundColor(orange); break;
            case "Mainan": textMainan.setTextColor(orange); lineMainan.setBackgroundColor(orange); break;
            case "Lainnya": textLainnya.setTextColor(orange); lineLainnya.setBackgroundColor(orange); break;
        }
    }

    // ====================================================
    // BOTTOM NAV
    // ====================================================
    private void setupBottomNav() {
        tabHome.setOnClickListener(v -> {
            Intent intent = new Intent(DaftarTokoSuka.this, DashboardPembeli2.class);
            startActivity(intent);
            overridePendingTransition(0, 0); // <- ini yang bikin langsung
        });

        tabProfile.setOnClickListener(v -> {
            Intent intent = new Intent(DaftarTokoSuka.this, ProfilePembeli.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        tabLikesFloating.setOnClickListener(v -> {
            Intent intent = new Intent(DaftarTokoSuka.this, DaftarTokoSuka.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });
    }
}
